# SUPPLYAI
> **"Predict. Optimize. Deliver."**  
> *AI-Powered Supply Chain Intelligence Platform for College Innovation Competition*

---

## ⚡ Quick Start: Running the Application

The application is already running live in your environment!
- **Local URL:** [http://localhost:3000](http://localhost:3000)
- **Local Network URL:** `http://175.20.0.179:3000`

### To run manually from terminal:
```bash
cd C:\Users\ikkir\.gemini\antigravity\scratch\supplyai
npm run dev
```

To build for production:
```bash
npm run build
```

---

## 🏗️ Project Architecture & Structure

```
supplyai/
├── src/
│   ├── types/
│   │   └── index.ts                 # Full TypeScript definitions (Products, Inventory, Routes, Orders, AI)
│   ├── data/
│   │   ├── products.ts              # 5 products with stock, unit prices, and lead times
│   │   ├── warehouses.ts            # 6 NCR nodes: Central Depot & Warehouses A through E with coordinates
│   │   ├── orders.ts                # 50 realistic demo orders with Indian infrastructure clients
│   │   ├── historicalDemand.ts      # 30-day historical demand generator and forecast trajectories
│   │   └── vehicles.ts              # 5 vehicles with capacity, driver names, and speeds
│   ├── utils/
│   │   ├── forecasting.ts           # Moving average, linear trend, and weekly seasonality heuristics
│   │   ├── inventoryCalculations.ts # Reorder Point (ROP), safety stock, and days remaining logic
│   │   ├── routeOptimizer.ts        # Nearest Neighbor + 2-Opt TSP heuristic algorithm
│   │   ├── deliveryRisk.ts          # Travel time estimation and multi-factor delay risk scoring
│   │   └── formatters.ts            # Indian currency (₹), distance, and duration formatting
│   ├── services/
│   │   ├── localAssistant.ts        # Natural language intent engine grounded in real-time supply chain state
│   │   └── storageService.ts        # LocalStorage persistence & "Reset Demo Data" handler
│   ├── components/
│   │   ├── layout/                  # Sidebar, Header, and MainLayout
│   │   ├── common/                  # StatCard, PurchaseOrderModal, AddOrderModal, AiExplainModal, CompetitionFlowModal
│   │   ├── dashboard/               # KpiGrid, AiInsightsPanel, 4 Recharts cards, ImpactSection
│   │   ├── demand/                  # ForecastMetrics, ForecastChart, ForecastExplain
│   │   ├── inventory/               # InventoryTable, InventoryAlertCard
│   │   ├── route/                   # SvgRouteMap (interactive canvas), RouteComparison (Before/After)
│   │   ├── delivery/                # DeliveryTable, DeliveryRiskCard (ORD-1003 spotlight)
│   │   ├── orders/                  # OrdersTable (50 orders, search, filters, Add Order)
│   │   ├── assistant/               # ChatInterface with suggestion chips & structured cards
│   │   └── settings/                # SettingsForm with configurable speed, lead times, and currency
│   ├── pages/                       # 8 complete dedicated application views
│   ├── App.tsx                      # Global state manager, modal handlers, and tab switcher
│   ├── main.tsx                     # React root renderer
│   └── index.css                    # Tailwind CSS, custom glassmorphism, and route flow animations
├── package.json
├── tailwind.config.js
├── vite.config.ts
└── tsconfig.json
```

---

## 🏆 Official 3-Minute Competition Demo Flow

Click the **"Competition Demo Flow"** button in the header at any time, or follow these steps:

1. **Step 1 – Executive Command (Dashboard):**
   - Review executive KPIs (Total Orders: 248, On-Time: 94.2%, Est. Cost Saved: ₹18,450).
   - Point out the active AI Insight: *"Steel demand is predicted to increase by 18% over the next 7 days."*

2. **Step 2 – Demand Forecast:**
   - Navigate to **Demand Forecast**, select **Steel**.
   - Show the trajectory chart (Actual vs Predicted) and explainable drivers under *"Why is demand changing?"*.
   - Click **"Generate New Forecast"** to demonstrate instant model re-convergence.

3. **Step 3 – Inventory Intelligence:**
   - Switch to **Inventory Intelligence**.
   - Point out **Steel** highlighted in red as **Critical** (only 2 days of buffer left).
   - Click **"Generate Purchase Order"**, edit quantity to **250 units**, and click **"Confirm & Dispatch PO"**.
   - Watch the stock count and health status immediately update to Healthy.

4. **Step 4 – Route Optimizer (2-Opt TSP):**
   - Navigate to **Route Optimizer**.
   - Point out the initial crisscrossing route (51.2 km | 2h 18m | ₹640).
   - Click **"OPTIMIZE ROUTE"**.
   - Watch the 1.5-second multi-stage analysis animation transition to the optimal sequence (`Depot → A → C → E → B → D`).
   - Highlight: **42.6 km | 1h 51m | ₹535 (8.6 km and 16.8% distance saved)**.

5. **Step 5 – Delivery Prediction:**
   - Open **Delivery Prediction**.
   - Review the AI spotlight on **ORD-1003 (Warehouse C)** flagged at **Medium Risk**.
   - Click **"Move to Route 2"** to apply the AI recommendation and resolve the potential delay.

6. **Step 6 – SupplyAI Copilot:**
   - Open **AI Assistant**.
   - Click the prompt: *"How can I reduce my supply-chain costs?"*
   - Observe the assistant synthesize telemetry across Demand, Inventory, Route Optimization, and Delivery Risks into a unified 4-pillar execution playbook.

7. **Step 7 – Executive Impact Return:**
   - Return to **Dashboard** and highlight the bottom ROI banner:
     - **16.8%** Distance cut
     - **12.0%** Cost cut
     - **94.2%** On-Time delivery
     - **91.6%** Forecast accuracy

---

## 🧠 Explainability & Demo Algorithms vs Production Integration

All algorithms are transparently implemented in clean TypeScript:

| Capability | Current Algorithm | Production Connection Path |
| :--- | :--- | :--- |
| **Demand Forecasting** | 7-day weighted moving average + linear trend slope + day-of-week seasonality decomposition | Connect to Python FastAPI microservice serving Facebook Prophet, ARIMA, or PyTorch LSTM |
| **Route Optimization** | Nearest Neighbor Greedy Heuristic + 2-Opt Iterative Edge-Swap Local Search | Connect to Google Maps Distance Matrix API / OR-Tools / OSRM |
| **Inventory Management** | Dynamic Reorder Point: $ROP = (d \times L) + SS$ | Connect to SAP / Oracle ERP database via PostgreSQL adapter |
| **Delivery ETA & Risk** | Haversine/coordinate distance $\div$ speed + dwell time with multi-factor risk scoring | Connect to IoT GPS telematics / Traccar server |
| **AI Copilot** | Grounded rule-based & regex intent matching extracting live state | Connect to Gemini 1.5 Pro / Flash via Google Gen AI SDK |
