export type ProductType = 'Cement' | 'Steel' | 'Bricks' | 'Pipes' | 'Tiles';

export interface Product {
  id: string;
  name: ProductType;
  sku: string;
  category: string;
  unit: string;
  unitPrice: number;
  leadTimeDays: number;
  supplier: string;
  description: string;
}

export type InventoryStatus = 'Healthy' | 'Warning' | 'Critical';

export interface InventoryItem {
  id: string;
  productId: string;
  product: ProductType;
  currentStock: number;
  dailyDemand: number;
  safetyStock: number;
  reorderPoint: number;
  daysRemaining: number;
  status: InventoryStatus;
  recommendedOrder: number;
  leadTimeDays: number;
  supplier: string;
  unitPrice: number;
  minOrderQuantity: number;
}

export interface DemandDataPoint {
  date: string;
  dayIndex: number;
  actualDemand?: number;
  predictedDemand?: number;
  confidenceUpper?: number;
  confidenceLower?: number;
  isForecast: boolean;
}

export interface ProductForecast {
  product: ProductType;
  currentAvgDemand: number;
  predictedAvgDemand: number;
  growthPct: number;
  confidencePct: number;
  periodDays: 7 | 14 | 30;
  explanation: string;
  trendReason: string;
  seasonalPattern: string;
  dataPoints: DemandDataPoint[];
}

export interface WarehouseLocation {
  id: string;
  name: string;
  code: string;
  x: number; // SVG canvas coordinate X (0-800)
  y: number; // SVG canvas coordinate Y (0-500)
  type: 'depot' | 'warehouse';
  address: string;
  city: string;
  demandUnits: number;
  priority: 'High' | 'Medium' | 'Low';
  deliveryWindow: string;
  contactPerson: string;
}

export interface RouteStop {
  stopNumber: number;
  location: WarehouseLocation;
  distanceFromPreviousKm: number;
  estimatedArrival: string;
}

export interface RouteOptimizationResult {
  initialSequence: string[];
  optimizedSequence: string[];
  initialDistanceKm: number;
  optimizedDistanceKm: number;
  distanceSavedKm: number;
  distanceSavedPct: number;
  initialTimeMinutes: number;
  optimizedTimeMinutes: number;
  timeSavedMinutes: number;
  initialFuelCost: number;
  optimizedFuelCost: number;
  fuelCostSaved: number;
  algorithmUsed: string;
  status: 'idle' | 'analyzing' | 'optimized';
}

export interface Vehicle {
  id: string;
  name: string;
  type: string;
  plateNumber: string;
  capacityUnits: number;
  currentLoad: number;
  driverName: string;
  status: 'Available' | 'On Route' | 'Maintenance';
  avgSpeedKmh: number;
}

export type OrderPriority = 'High' | 'Medium' | 'Low';
export type OrderStatus = 'Pending' | 'Processing' | 'In Transit' | 'Delivered' | 'Delayed';
export type DeliveryRisk = 'Low' | 'Medium' | 'High';

export interface Order {
  id: string;
  orderNumber: string;
  customer: string;
  product: ProductType;
  quantity: number;
  priority: OrderPriority;
  destination: string;
  destinationWarehouseId: string;
  distanceKm: number;
  vehicle: string;
  eta: string;
  risk: DeliveryRisk;
  status: OrderStatus;
  orderDate: string;
  deliveryWindow: string;
  riskReasons?: string[];
  aiRecommendation?: string;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplier: string;
  product: ProductType;
  quantity: number;
  unitPrice: number;
  estimatedCost: number;
  expectedDelivery: string;
  createdAt: string;
  status: 'Draft' | 'Submitted' | 'Approved';
}

export interface AppSettings {
  companyName: string;
  defaultWarehouse: string;
  currency: string;
  currencySymbol: string;
  avgVehicleSpeedKmh: number;
  defaultLeadTimeDays: number;
  safetyStockFactor: number;
  fuelCostPerKm: number;
  demoMode: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  timestamp: string;
  text: string;
  category?: 'inventory' | 'forecast' | 'routes' | 'delivery' | 'general';
  cards?: {
    title: string;
    description: string;
    type: 'metric' | 'alert' | 'route' | 'action';
    data?: Record<string, any>;
  }[];
}

export interface AiExplainabilityData {
  title: string;
  prediction: string;
  confidence: number;
  why: string;
  action: string;
  metric?: string;
  additionalNotes?: string;
}
