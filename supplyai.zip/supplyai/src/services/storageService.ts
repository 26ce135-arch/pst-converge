import {
  InventoryItem,
  Order,
  PurchaseOrder,
  AppSettings,
  ChatMessage,
  RouteOptimizationResult,
} from '../types';
import { INITIAL_INVENTORY } from '../data/products';
import { INITIAL_ORDERS } from '../data/orders';
import { BENCHMARK_ROUTE_RESULT } from '../data/warehouses';

const STORAGE_KEYS = {
  INVENTORY: 'supplyai_inventory_v1',
  ORDERS: 'supplyai_orders_v1',
  PURCHASE_ORDERS: 'supplyai_purchase_orders_v1',
  SETTINGS: 'supplyai_settings_v1',
  ROUTE_RESULT: 'supplyai_route_result_v1',
  CHAT_MESSAGES: 'supplyai_chat_messages_v1',
};

export const DEFAULT_SETTINGS: AppSettings = {
  companyName: 'Apex Logistics India Ltd.',
  defaultWarehouse: 'Warehouse A (North Okhla)',
  currency: 'INR',
  currencySymbol: '₹',
  avgVehicleSpeedKmh: 38,
  defaultLeadTimeDays: 3,
  safetyStockFactor: 1.5,
  fuelCostPerKm: 12.55,
  demoMode: true,
};

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-welcome',
    sender: 'assistant',
    timestamp: 'Just now',
    text: `Hello! I am **SupplyAI Assistant**, your real-time supply chain copilot.\n\nI can monitor your inventory thresholds, compute 2-Opt route savings, diagnose delivery delay risks, and analyze predictive demand trends.\n\nClick any quick prompt below or type your question to begin.`,
    category: 'general',
  },
];

export const StorageService = {
  getInventory(): InventoryItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.INVENTORY);
      return data ? JSON.parse(data) : INITIAL_INVENTORY;
    } catch {
      return INITIAL_INVENTORY;
    }
  },

  saveInventory(items: InventoryItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save inventory to localStorage', e);
    }
  },

  getOrders(): Order[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return data ? JSON.parse(data) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  },

  saveOrders(orders: Order[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.error('Failed to save orders to localStorage', e);
    }
  },

  getPurchaseOrders(): PurchaseOrder[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PURCHASE_ORDERS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  savePurchaseOrders(pos: PurchaseOrder[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PURCHASE_ORDERS, JSON.stringify(pos));
    } catch (e) {
      console.error('Failed to save purchase orders', e);
    }
  },

  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return data ? JSON.parse(data) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: AppSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  },

  getRouteResult(): RouteOptimizationResult {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ROUTE_RESULT);
      return data ? JSON.parse(data) : BENCHMARK_ROUTE_RESULT;
    } catch {
      return BENCHMARK_ROUTE_RESULT;
    }
  },

  saveRouteResult(result: RouteOptimizationResult): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ROUTE_RESULT, JSON.stringify(result));
    } catch (e) {
      console.error('Failed to save route result', e);
    }
  },

  getChatMessages(): ChatMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHAT_MESSAGES);
      return data ? JSON.parse(data) : INITIAL_CHAT_MESSAGES;
    } catch {
      return INITIAL_CHAT_MESSAGES;
    }
  },

  saveChatMessages(messages: ChatMessage[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify(messages));
    } catch (e) {
      console.error('Failed to save chat messages', e);
    }
  },

  resetAllDemoData(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.INVENTORY);
      localStorage.removeItem(STORAGE_KEYS.ORDERS);
      localStorage.removeItem(STORAGE_KEYS.PURCHASE_ORDERS);
      localStorage.removeItem(STORAGE_KEYS.SETTINGS);
      localStorage.removeItem(STORAGE_KEYS.ROUTE_RESULT);
      localStorage.removeItem(STORAGE_KEYS.CHAT_MESSAGES);
    } catch (e) {
      console.error('Failed to reset demo data', e);
    }
  },
};
