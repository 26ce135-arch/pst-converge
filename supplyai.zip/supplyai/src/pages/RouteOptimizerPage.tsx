import React, { useState } from 'react';
import { RouteOptimizationResult } from '../types';
import { SvgRouteMap } from '../components/route/SvgRouteMap';
import { RouteComparison } from '../components/route/RouteComparison';
import { Gauge, Layers, Clock, ShieldCheck, AlertCircle } from 'lucide-react';

interface RouteOptimizerPageProps {
  routeResult: RouteOptimizationResult;
  onUpdateRouteResult: (res: RouteOptimizationResult) => void;
  currencySymbol?: string;
}

export const RouteOptimizerPage: React.FC<RouteOptimizerPageProps> = ({
  routeResult,
  onUpdateRouteResult,
  currencySymbol = '₹',
}) => {
  const [isOptimized, setIsOptimized] = useState(routeResult.status === 'optimized');

  const handleRunOptimization = () => {
    setIsOptimized(true);
    onUpdateRouteResult({
      ...routeResult,
      status: 'optimized',
    });
  };

  const activeSequence = isOptimized
    ? routeResult.optimizedSequence
    : routeResult.initialSequence;

  return (
    <div className="space-y-6">
      {/* 1. Comparison & Optimization Action */}
      <RouteComparison
        result={routeResult}
        isOptimized={isOptimized}
        onRunOptimization={handleRunOptimization}
        currencySymbol={currencySymbol}
      />

      {/* 2. Visual Route Canvas */}
      <SvgRouteMap sequence={activeSequence} isOptimized={isOptimized} />

      {/* 3. Optimization Multi-Factor Matrix */}
      <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Optimization Constraints & Heuristic Parameters
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60">
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <Gauge className="w-3.5 h-3.5 text-indigo-400" />
              <span>Distance & Geometry</span>
            </div>
            <p className="text-[11px] text-slate-400">
              2-Opt edge inversion eliminates intersecting transit corridors between nodes.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60">
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Delivery Priority</span>
            </div>
            <p className="text-[11px] text-slate-400">
              High-priority hubs (WH-A and WH-B) prioritized within first half of dispatch circuit.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60">
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <Layers className="w-3.5 h-3.5 text-sky-400" />
              <span>Vehicle Capacity</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Payload weighted against truck axle rating (capped at 85% gross limit).
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60">
            <div className="flex items-center gap-2 text-xs font-semibold text-white mb-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Delivery Window</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Guarantees arrival prior to warehouse receiving dock cutoff times.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
