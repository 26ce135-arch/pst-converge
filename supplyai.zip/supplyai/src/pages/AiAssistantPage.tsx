import React from 'react';
import { ChatMessage } from '../types';
import { ChatInterface } from '../components/assistant/ChatInterface';

interface AiAssistantPageProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isLoading?: boolean;
}

export const AiAssistantPage: React.FC<AiAssistantPageProps> = ({
  messages,
  onSendMessage,
  isLoading,
}) => {
  return (
    <div className="space-y-6">
      <ChatInterface
        messages={messages}
        onSendMessage={onSendMessage}
        isLoading={isLoading}
      />
    </div>
  );
};
