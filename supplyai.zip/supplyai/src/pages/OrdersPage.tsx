import React from 'react';
import { Order } from '../types';
import { OrdersTable } from '../components/orders/OrdersTable';

interface OrdersPageProps {
  orders: Order[];
  onOpenAddModal: () => void;
}

export const OrdersPage: React.FC<OrdersPageProps> = ({ orders, onOpenAddModal }) => {
  return (
    <div className="space-y-6">
      <OrdersTable orders={orders} onOpenAddModal={onOpenAddModal} />
    </div>
  );
};
