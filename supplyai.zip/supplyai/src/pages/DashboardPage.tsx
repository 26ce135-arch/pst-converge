import React from 'react';
import { KpiGrid } from '../components/dashboard/KpiGrid';
import { AiInsightsPanel } from '../components/dashboard/AiInsightsPanel';
import { DemandTrendChart } from '../components/dashboard/DemandTrendChart';
import { OrdersOverviewChart } from '../components/dashboard/OrdersOverviewChart';
import { DeliveryPerformanceChart } from '../components/dashboard/DeliveryPerformanceChart';
import { InventoryHealthCard } from '../components/dashboard/InventoryHealthCard';
import { ImpactSection } from '../components/dashboard/ImpactSection';
import { InventoryItem, Order } from '../types';
import { NavTab } from '../components/layout/Sidebar';

interface DashboardPageProps {
  inventory: InventoryItem[];
  orders: Order[];
  onNavigate: (tab: NavTab) => void;
  onOpenExplainModal: () => void;
  currencySymbol?: string;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  inventory,
  orders,
  onNavigate,
  onOpenExplainModal,
  currencySymbol = '₹',
}) => {
  const inventoryAlertsCount = inventory.filter((i) => i.status !== 'Healthy').length;

  return (
    <div className="space-y-6">
      {/* 1. KPI Cards Grid */}
      <KpiGrid
        onNavigate={onNavigate}
        currencySymbol={currencySymbol}
        totalOrdersCount={248}
        inventoryAlertsCount={inventoryAlertsCount}
      />

      {/* 2. AI Insights Panel with working buttons */}
      <AiInsightsPanel
        onNavigate={onNavigate}
        onOpenExplainModal={onOpenExplainModal}
      />

      {/* 3. Operational Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DemandTrendChart />
        <OrdersOverviewChart />
        <DeliveryPerformanceChart />
        <InventoryHealthCard inventory={inventory} onNavigate={onNavigate} />
      </div>

      {/* 4. Demonstrated System Impact Section */}
      <ImpactSection />
    </div>
  );
};
