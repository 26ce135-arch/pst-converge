import React from 'react';
import { InventoryItem } from '../types';
import { InventoryTable } from '../components/inventory/InventoryTable';
import { InventoryAlertCard } from '../components/inventory/InventoryAlertCard';

interface InventoryIntelligencePageProps {
  inventory: InventoryItem[];
  onOpenPurchaseOrder: (item: InventoryItem) => void;
  onOpenExplain: (item: InventoryItem) => void;
}

export const InventoryIntelligencePage: React.FC<InventoryIntelligencePageProps> = ({
  inventory,
  onOpenPurchaseOrder,
  onOpenExplain,
}) => {
  const steelItem = inventory.find((i) => i.product === 'Steel');

  return (
    <div className="space-y-6">
      {/* Steel Inventory Alert Banner */}
      <InventoryAlertCard
        criticalItem={steelItem}
        onOpenPurchaseOrder={onOpenPurchaseOrder}
      />

      {/* Main Inventory Health Table */}
      <InventoryTable
        inventory={inventory}
        onOpenPurchaseOrder={onOpenPurchaseOrder}
        onOpenExplain={onOpenExplain}
      />
    </div>
  );
};
