import React from 'react';
import { Order } from '../types';
import { DeliveryTable } from '../components/delivery/DeliveryTable';
import { DeliveryRiskCard } from '../components/delivery/DeliveryRiskCard';

interface DeliveryPredictionPageProps {
  orders: Order[];
  onMoveOrderToRoute2: (orderNumber: string) => void;
  onSelectOrder: (order: Order) => void;
}

export const DeliveryPredictionPage: React.FC<DeliveryPredictionPageProps> = ({
  orders,
  onMoveOrderToRoute2,
  onSelectOrder,
}) => {
  const order1003 = orders.find((o) => o.orderNumber === 'ORD-1003');

  return (
    <div className="space-y-6">
      {/* AI Risk Prediction Spotlight */}
      <DeliveryRiskCard
        order1003={order1003}
        onApplyMitigation={() => onMoveOrderToRoute2('ORD-1003')}
      />

      {/* Dispatches & Delay Predictions Table */}
      <DeliveryTable orders={orders} onSelectOrder={onSelectOrder} />
    </div>
  );
};
