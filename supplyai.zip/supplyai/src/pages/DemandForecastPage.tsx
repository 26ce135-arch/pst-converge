import React, { useState } from 'react';
import { ProductType } from '../types';
import { getProductForecast } from '../data/historicalDemand';
import { ForecastMetrics } from '../components/demand/ForecastMetrics';
import { ForecastChart } from '../components/demand/ForecastChart';
import { ForecastExplain } from '../components/demand/ForecastExplain';
import { RefreshCw, CheckCircle2, Sparkles, Loader2 } from 'lucide-react';

export const DemandForecastPage: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<ProductType>('Cement');
  const [period, setPeriod] = useState<7 | 14 | 30>(7);
  const [isGenerating, setIsGenerating] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [forecastSeedModifier, setForecastSeedModifier] = useState(0);

  const forecast = getProductForecast(selectedProduct, period, forecastSeedModifier);

  const handleGenerateForecast = () => {
    setIsGenerating(true);
    setSuccessMessage(null);

    setTimeout(() => {
      // Simulate recalculation with slight variation
      setForecastSeedModifier((prev) => (prev === 0 ? 0.03 : 0));
      setIsGenerating(false);
      setSuccessMessage(`New ${period}-day forecast model converged with 91.6% confidence score!`);
      setTimeout(() => setSuccessMessage(null), 4000);
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Product selector tabs */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mr-1">Product:</span>
          {(['Cement', 'Steel', 'Bricks', 'Pipes', 'Tiles'] as ProductType[]).map((prod) => (
            <button
              key={prod}
              onClick={() => setSelectedProduct(prod)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedProduct === prod
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              {prod}
            </button>
          ))}
        </div>

        {/* Period toggle and Generate Button */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            {([7, 14, 30] as const).map((days) => (
              <button
                key={days}
                onClick={() => setPeriod(days)}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  period === days
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {days} Days
              </button>
            ))}
          </div>

          <button
            onClick={handleGenerateForecast}
            disabled={isGenerating}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 transition-all flex items-center gap-2 shadow-lg shadow-indigo-600/30"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Computing Model...</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-3.5 h-3.5 text-indigo-200" />
                <span>Generate New Forecast</span>
              </>
            )}
          </button>
        </div>
      </div>

      {successMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* KPI Metrics */}
      <ForecastMetrics forecast={forecast} />

      {/* Recharts Trajectory Line Chart */}
      <ForecastChart forecast={forecast} />

      {/* Why is demand changing? */}
      <ForecastExplain forecast={forecast} />
    </div>
  );
};
