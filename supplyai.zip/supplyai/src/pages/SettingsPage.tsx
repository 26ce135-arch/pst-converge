import React from 'react';
import { AppSettings } from '../types';
import { SettingsForm } from '../components/settings/SettingsForm';

interface SettingsPageProps {
  settings: AppSettings;
  onSave: (settings: AppSettings) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ settings, onSave }) => {
  return (
    <div className="space-y-6">
      <SettingsForm settings={settings} onSave={onSave} />
    </div>
  );
};
