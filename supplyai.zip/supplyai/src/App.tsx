import React, { useState, useEffect } from 'react';
import { MainLayout } from './components/layout/MainLayout';
import { NavTab } from './components/layout/Sidebar';
import { DashboardPage } from './pages/DashboardPage';
import { DemandForecastPage } from './pages/DemandForecastPage';
import { InventoryIntelligencePage } from './pages/InventoryIntelligencePage';
import { RouteOptimizerPage } from './pages/RouteOptimizerPage';
import { DeliveryPredictionPage } from './pages/DeliveryPredictionPage';
import { OrdersPage } from './pages/OrdersPage';
import { AiAssistantPage } from './pages/AiAssistantPage';
import { SettingsPage } from './pages/SettingsPage';
import { PurchaseOrderModal } from './components/common/PurchaseOrderModal';
import { AddOrderModal } from './components/common/AddOrderModal';
import { AiExplainModal } from './components/common/AiExplainModal';
import { CompetitionFlowModal } from './components/common/CompetitionFlowModal';
import { StorageService, DEFAULT_SETTINGS } from './services/storageService';
import { queryLocalAssistant } from './services/localAssistant';
import {
  InventoryItem,
  Order,
  RouteOptimizationResult,
  AppSettings,
  ChatMessage,
  AiExplainabilityData,
} from './types';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [inventory, setInventory] = useState<InventoryItem[]>(StorageService.getInventory());
  const [orders, setOrders] = useState<Order[]>(StorageService.getOrders());
  const [routeResult, setRouteResult] = useState<RouteOptimizationResult>(StorageService.getRouteResult());
  const [settings, setSettings] = useState<AppSettings>(StorageService.getSettings());
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(StorageService.getChatMessages());
  const [isAssistantThinking, setIsAssistantThinking] = useState(false);

  // Modals state
  const [poModalItem, setPoModalItem] = useState<InventoryItem | null>(null);
  const [isAddOrderOpen, setIsAddOrderOpen] = useState(false);
  const [explainData, setExplainData] = useState<AiExplainabilityData | null>(null);
  const [isCompetitionFlowOpen, setIsCompetitionFlowOpen] = useState(false);

  // Persist changes
  useEffect(() => {
    StorageService.saveInventory(inventory);
  }, [inventory]);

  useEffect(() => {
    StorageService.saveOrders(orders);
  }, [orders]);

  useEffect(() => {
    StorageService.saveRouteResult(routeResult);
  }, [routeResult]);

  useEffect(() => {
    StorageService.saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    StorageService.saveChatMessages(chatMessages);
  }, [chatMessages]);

  // Handle PO Creation
  const handleConfirmPO = (po: {
    product: string;
    quantity: number;
    supplier: string;
    expectedDelivery: string;
    estimatedCost: number;
  }) => {
    // Replenish inventory stock
    setInventory((prev) =>
      prev.map((item) => {
        if (item.product === po.product) {
          const newStock = item.currentStock + po.quantity;
          const newDays = Math.floor(newStock / item.dailyDemand);
          return {
            ...item,
            currentStock: newStock,
            daysRemaining: newDays,
            status: newStock >= item.reorderPoint ? 'Healthy' : 'Warning',
            recommendedOrder: 0,
          };
        }
        return item;
      })
    );
  };

  // Handle Add Order
  const handleAddOrder = (newOrderData: Partial<Order>) => {
    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: `ORD-${1000 + orders.length + 1}`,
      customer: newOrderData.customer || 'New Customer',
      product: newOrderData.product || 'Cement',
      quantity: newOrderData.quantity || 100,
      priority: newOrderData.priority || 'Medium',
      destination: newOrderData.destination || 'Warehouse A',
      destinationWarehouseId: newOrderData.destinationWarehouseId || 'loc-wh-a',
      distanceKm: newOrderData.distanceKm || 12.0,
      vehicle: newOrderData.vehicle || 'Truck 01',
      eta: newOrderData.eta || '17:00',
      risk: newOrderData.risk || 'Low',
      status: 'Pending',
      orderDate: 'Just now',
      deliveryWindow: newOrderData.deliveryWindow || '14:00 - 18:00',
    };

    setOrders((prev) => [newOrder, ...prev]);
  };

  // Move Order to Route 2 (Demo Step 5)
  const handleMoveOrderToRoute2 = (orderNumber: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.orderNumber === orderNumber) {
          return {
            ...ord,
            vehicle: 'Truck 02 (Route 2 Dedicated Express)',
            eta: '15:40',
            risk: 'Low',
            riskReasons: ['Reallocated away from congested eastern corridor to express carrier.'],
            aiRecommendation: 'Resolved: SLA target secured with 50 minutes window slack.',
          };
        }
        return ord;
      })
    );
  };

  // AI Assistant Interaction
  const handleSendMessage = (text: string) => {
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      timestamp: 'Just now',
      text,
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setIsAssistantThinking(true);

    setTimeout(() => {
      const response = queryLocalAssistant(text, {
        inventory,
        orders,
        routeResult,
        currencySymbol: settings.currencySymbol,
      });

      const botMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        timestamp: 'Just now',
        text: response.text,
        category: response.category,
        cards: response.cards,
      };

      setChatMessages((prev) => [...prev, botMsg]);
      setIsAssistantThinking(false);
    }, 600);
  };

  // Reset Demo Data
  const handleResetDemo = () => {
    StorageService.resetAllDemoData();
    setInventory(StorageService.getInventory());
    setOrders(StorageService.getOrders());
    setRouteResult(StorageService.getRouteResult());
    setSettings(DEFAULT_SETTINGS);
    setChatMessages(StorageService.getChatMessages());
    setActiveTab('dashboard');
  };

  const inventoryAlertsCount = inventory.filter((i) => i.status !== 'Healthy').length;
  const deliveryRisksCount = orders.filter((o) => o.risk === 'Medium' || o.risk === 'High' || o.status === 'Delayed').length;

  return (
    <MainLayout
      activeTab={activeTab}
      onSelectTab={setActiveTab}
      onResetDemo={handleResetDemo}
      onOpenCompetitionFlow={() => setIsCompetitionFlowOpen(true)}
      inventoryAlertCount={inventoryAlertsCount}
      deliveryRiskCount={deliveryRisksCount}
    >
      {activeTab === 'dashboard' && (
        <DashboardPage
          inventory={inventory}
          orders={orders}
          onNavigate={setActiveTab}
          onOpenExplainModal={() =>
            setExplainData({
              title: 'Multi-Pillar Supply Chain Synthesis',
              prediction: 'Steel demand surges +18% while Warehouse B stock reaches threshold in 2 days.',
              confidence: 91,
              why: 'Heavy structural foundation pours starting in Sector 63 combined with 4-day supplier lead time.',
              action: 'Execute 250 unit purchase order with Tata Structural Logistics and activate 2-Opt route sequence.',
              metric: '16.8% Transit Distance Cut',
            })
          }
          currencySymbol={settings.currencySymbol}
        />
      )}

      {activeTab === 'demand' && <DemandForecastPage />}

      {activeTab === 'inventory' && (
        <InventoryIntelligencePage
          inventory={inventory}
          onOpenPurchaseOrder={(item) => setPoModalItem(item)}
          onOpenExplain={(item) =>
            setExplainData({
              title: `${item.product} Inventory Threshold Diagnosis`,
              prediction: `Stock reaches depletion threshold in ${item.daysRemaining} days at current ${item.dailyDemand}/day demand.`,
              confidence: 93,
              why: `Daily consumption exceeds safe buffer during ${item.leadTimeDays}-day replenishment window.`,
              action: item.recommendedOrder > 0 ? `Procure ${item.recommendedOrder} units.` : 'Monitor consumption.',
              metric: `ROP: ${item.reorderPoint} Units`,
            })
          }
        />
      )}

      {activeTab === 'route' && (
        <RouteOptimizerPage
          routeResult={routeResult}
          onUpdateRouteResult={setRouteResult}
          currencySymbol={settings.currencySymbol}
        />
      )}

      {activeTab === 'delivery' && (
        <DeliveryPredictionPage
          orders={orders}
          onMoveOrderToRoute2={handleMoveOrderToRoute2}
          onSelectOrder={(order) =>
            setExplainData({
              title: `${order.orderNumber} Delivery SLA Risk Assessment`,
              prediction: `Arrival at ${order.destination} projected for ${order.eta}.`,
              confidence: 88,
              why: order.riskReasons?.join('; ') || 'Standard corridor transit velocity.',
              action: order.aiRecommendation || 'Maintain routine line-haul dispatch.',
              metric: `${order.distanceKm} km transit`,
            })
          }
        />
      )}

      {activeTab === 'orders' && (
        <OrdersPage orders={orders} onOpenAddModal={() => setIsAddOrderOpen(true)} />
      )}

      {activeTab === 'assistant' && (
        <AiAssistantPage
          messages={chatMessages}
          onSendMessage={handleSendMessage}
          isLoading={isAssistantThinking}
        />
      )}

      {activeTab === 'settings' && (
        <SettingsPage settings={settings} onSave={setSettings} />
      )}

      {/* Global Modals */}
      <PurchaseOrderModal
        isOpen={Boolean(poModalItem)}
        onClose={() => setPoModalItem(null)}
        item={poModalItem}
        onConfirm={handleConfirmPO}
        currencySymbol={settings.currencySymbol}
      />

      <AddOrderModal
        isOpen={isAddOrderOpen}
        onClose={() => setIsAddOrderOpen(false)}
        onAddOrder={handleAddOrder}
      />

      <AiExplainModal
        isOpen={Boolean(explainData)}
        onClose={() => setExplainData(null)}
        data={explainData}
      />

      <CompetitionFlowModal
        isOpen={isCompetitionFlowOpen}
        onClose={() => setIsCompetitionFlowOpen(false)}
        onNavigateStep={setActiveTab}
      />
    </MainLayout>
  );
};
