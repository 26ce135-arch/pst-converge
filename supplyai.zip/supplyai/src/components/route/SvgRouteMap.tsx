import React from 'react';
import { WarehouseLocation } from '../../types';
import { WAREHOUSE_LOCATIONS } from '../../data/warehouses';
import { MapPin, Navigation } from 'lucide-react';

interface SvgRouteMapProps {
  sequence: string[];
  isOptimized: boolean;
}

export const SvgRouteMap: React.FC<SvgRouteMapProps> = ({ sequence, isOptimized }) => {
  const locMap = new Map<string, WarehouseLocation>();
  WAREHOUSE_LOCATIONS.forEach((l) => locMap.set(l.code, l));

  const points = sequence
    .map((code) => locMap.get(code))
    .filter((loc): loc is WarehouseLocation => Boolean(loc));

  // Generate SVG path string connecting the nodes
  const pathD = points.reduce((acc, pt, idx) => {
    return idx === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
  }, '');

  return (
    <div className="glass-card rounded-2xl p-5 border border-slate-800 relative overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <span>Visual Route & Corridor Canvas</span>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                isOptimized
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              }`}
            >
              {isOptimized ? '2-Opt Optimized Tour' : 'Naive Initial Loop'}
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Regional NCR node layout: Depot and Warehouses A through E
          </p>
        </div>

        <div className="text-xs font-mono text-slate-400 flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded-lg">
          <Navigation className="w-3.5 h-3.5 text-indigo-400" />
          <span>{sequence.join(' → ')}</span>
        </div>
      </div>

      {/* SVG Canvas Map */}
      <div className="relative w-full h-[360px] bg-[#070b14] rounded-xl border border-slate-800 overflow-hidden flex items-center justify-center">
        {/* Grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b08_1px,transparent_1px),linear-gradient(to_bottom,#1e293b08_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

        <svg viewBox="0 0 740 440" className="w-full h-full">
          {/* Connecting Path */}
          <path
            d={pathD}
            fill="none"
            stroke={isOptimized ? '#10b981' : '#f59e0b'}
            strokeWidth="3.5"
            strokeDasharray={isOptimized ? 'none' : '6 6'}
            strokeLinecap="round"
            strokeLinejoin="round"
            className={isOptimized ? 'animate-route-flow' : ''}
          />

          {/* Render Warehouse and Depot Nodes */}
          {WAREHOUSE_LOCATIONS.map((loc) => {
            const isDepot = loc.type === 'depot';
            const orderIndex = sequence.indexOf(loc.code);

            return (
              <g key={loc.id} className="cursor-pointer transition-transform hover:scale-110">
                {/* Glow ring for Depot or active stops */}
                {isDepot && (
                  <circle
                    cx={loc.x}
                    cy={loc.y}
                    r="24"
                    fill="none"
                    stroke="#6366f1"
                    strokeWidth="2"
                    opacity="0.4"
                    className="animate-pulse"
                  />
                )}

                {/* Node Outer Circle */}
                <circle
                  cx={loc.x}
                  cy={loc.y}
                  r={isDepot ? 18 : 15}
                  fill={isDepot ? '#4f46e5' : '#1e293b'}
                  stroke={isDepot ? '#818cf8' : '#64748b'}
                  strokeWidth="2"
                />

                {/* Node Sequence Label */}
                <text
                  x={loc.x}
                  y={loc.y + 4}
                  textAnchor="middle"
                  fill="#ffffff"
                  fontSize={isDepot ? '11' : '10'}
                  fontWeight="bold"
                >
                  {isDepot ? '★' : orderIndex >= 0 ? orderIndex : loc.code.replace('WH-', '')}
                </text>

                {/* Text Badge under Node */}
                <rect
                  x={loc.x - 34}
                  y={loc.y + 20}
                  width="68"
                  height="16"
                  rx="4"
                  fill="#0f172a"
                  stroke="#334155"
                  strokeWidth="1"
                />
                <text
                  x={loc.x}
                  y={loc.y + 31}
                  textAnchor="middle"
                  fill="#cbd5e1"
                  fontSize="9"
                  fontWeight="600"
                >
                  {loc.code}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Live Traffic Disclaimer */}
        <div className="absolute bottom-3 left-3 bg-slate-900/90 border border-slate-800 text-[10px] text-slate-400 px-2.5 py-1 rounded-lg">
          <span className="text-amber-400 font-semibold">Note:</span> Real-time GPS traffic API unavailable (Euclidean network distance modeled).
        </div>
      </div>
    </div>
  );
};
