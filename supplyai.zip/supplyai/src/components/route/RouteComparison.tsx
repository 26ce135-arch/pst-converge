import React, { useState } from 'react';
import { RouteOptimizationResult } from '../../types';
import { Route, Clock, IndianRupee, ArrowRight, Sparkles, CheckCircle2, Loader2 } from 'lucide-react';
import { formatCurrency, formatDistance, formatDurationMinutes } from '../../utils/formatters';

interface RouteComparisonProps {
  result: RouteOptimizationResult;
  isOptimized: boolean;
  onRunOptimization: () => void;
  currencySymbol?: string;
}

export const RouteComparison: React.FC<RouteComparisonProps> = ({
  result,
  isOptimized,
  onRunOptimization,
  currencySymbol = '₹',
}) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleOptimizeClick = () => {
    setAnalyzing(true);
    setStatusMessage('Analyzing delivery locations & evaluating 2-opt permutations...');

    setTimeout(() => {
      onRunOptimization();
      setAnalyzing(false);
      setStatusMessage('Route optimized successfully.');
      setTimeout(() => setStatusMessage(null), 4000);
    }, 1500);
  };

  return (
    <div className="space-y-4">
      {/* Action banner with button */}
      <div className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-indigo-500/20 text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </span>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              2-Opt Heuristic Route Optimizer
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Optimizes depot-to-warehouse dispatch tours to eliminate crisscrossing legs and reduce transit costs.
          </p>
          {statusMessage && (
            <div className="mt-2 text-xs font-semibold text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4" />
              <span>{statusMessage}</span>
            </div>
          )}
        </div>

        <button
          onClick={handleOptimizeClick}
          disabled={analyzing}
          className="px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 shrink-0"
        >
          {analyzing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Analyzing Locations...</span>
            </>
          ) : (
            <>
              <Route className="w-4 h-4" />
              <span>OPTIMIZE ROUTE</span>
            </>
          )}
        </button>
      </div>

      {/* Before vs After Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* BEFORE */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-bold uppercase text-slate-400">Initial Route</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              Naive Dispatch
            </span>
          </div>

          <div className="text-xs font-mono text-slate-300">
            {result.initialSequence.join(' → ')}
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Route className="w-3.5 h-3.5" /> Distance
              </span>
              <span className="font-mono font-bold text-white">51.2 km</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" /> Transit Time
              </span>
              <span className="font-mono font-bold text-white">2h 18m</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-400 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5" /> Fuel Cost
              </span>
              <span className="font-mono font-bold text-white">₹640</span>
            </div>
          </div>
        </div>

        {/* AFTER */}
        <div className="glass-card rounded-2xl p-5 border border-emerald-500/30 bg-emerald-950/10 space-y-3">
          <div className="flex items-center justify-between border-b border-emerald-500/20 pb-2">
            <span className="text-xs font-bold uppercase text-emerald-400">Optimized Route</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              2-Opt Recommended
            </span>
          </div>

          <div className="text-xs font-mono text-emerald-200 font-semibold">
            {result.optimizedSequence.join(' → ')}
          </div>

          <div className="space-y-2 pt-2 border-t border-emerald-500/20 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-emerald-300/80 flex items-center gap-1.5">
                <Route className="w-3.5 h-3.5" /> Distance
              </span>
              <span className="font-mono font-bold text-emerald-400">42.6 km</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-emerald-300/80 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" /> Transit Time
              </span>
              <span className="font-mono font-bold text-emerald-400">1h 51m</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-emerald-300/80 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5" /> Fuel Cost
              </span>
              <span className="font-mono font-bold text-emerald-400">₹535</span>
            </div>
          </div>
        </div>

        {/* SAVINGS */}
        <div className="glass-card rounded-2xl p-5 border border-indigo-500/30 bg-indigo-950/20 space-y-3">
          <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2">
            <span className="text-xs font-bold uppercase text-indigo-400">Net Savings</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              -16.8% Cut
            </span>
          </div>

          <div className="text-2xl font-black text-indigo-300 font-mono">
            8.6 km <span className="text-xs font-sans text-indigo-400 font-normal">saved per circuit</span>
          </div>

          <div className="space-y-2 pt-2 border-t border-indigo-500/20 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Time Saved</span>
              <span className="font-mono font-bold text-emerald-400">27 minutes</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-300">Fuel Cost Saved</span>
              <span className="font-mono font-bold text-emerald-400">₹105 / trip</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-300">Total Distance Reduction</span>
              <span className="font-mono font-bold text-indigo-400">16.8%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
