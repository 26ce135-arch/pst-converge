import React from 'react';
import { InventoryItem } from '../../types';
import { AlertCircle, ShoppingCart } from 'lucide-react';

interface InventoryTableProps {
  inventory: InventoryItem[];
  onOpenPurchaseOrder: (item: InventoryItem) => void;
  onOpenExplain: (item: InventoryItem) => void;
}

export const InventoryTable: React.FC<InventoryTableProps> = ({
  inventory,
  onOpenPurchaseOrder,
  onOpenExplain,
}) => {
  return (
    <div className="glass-card rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
      <div className="p-5 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-white">Dynamic Reorder Point (ROP) & Health Matrix</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Calculated via: <code>Reorder Point = Expected Demand During Lead Time + Safety Stock</code>
          </p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/80 text-slate-400 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-800">
            <tr>
              <th className="px-5 py-3.5">Product</th>
              <th className="px-4 py-3.5">Current Stock</th>
              <th className="px-4 py-3.5">Daily Demand</th>
              <th className="px-4 py-3.5">Safety Stock</th>
              <th className="px-4 py-3.5">Reorder Point</th>
              <th className="px-4 py-3.5">Days Remaining</th>
              <th className="px-4 py-3.5">Status</th>
              <th className="px-4 py-3.5">Recommended Order</th>
              <th className="px-5 py-3.5 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80 text-slate-300">
            {inventory.map((item) => {
              const isCritical = item.status === 'Critical';
              const isWarning = item.status === 'Warning';

              return (
                <tr
                  key={item.id}
                  className={`hover:bg-slate-800/40 transition-colors ${
                    isCritical ? 'bg-rose-950/15' : isWarning ? 'bg-amber-950/10' : ''
                  }`}
                >
                  <td className="px-5 py-4 font-bold text-white">
                    <div className="flex items-center gap-2">
                      <span>{item.product}</span>
                      {isCritical && (
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                      )}
                    </div>
                  </td>

                  <td className="px-4 py-4 font-mono font-semibold text-white">
                    {item.currentStock}
                  </td>

                  <td className="px-4 py-4 font-mono text-slate-300">
                    {item.dailyDemand}/day
                  </td>

                  <td className="px-4 py-4 font-mono text-slate-400">
                    {item.safetyStock}
                  </td>

                  <td className="px-4 py-4 font-mono font-medium text-slate-200">
                    {item.reorderPoint}
                  </td>

                  <td className="px-4 py-4 font-mono">
                    <span
                      className={`font-bold ${
                        item.daysRemaining <= 2
                          ? 'text-rose-400'
                          : item.daysRemaining <= 5
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {item.daysRemaining} days
                    </span>
                  </td>

                  <td className="px-4 py-4">
                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        isCritical
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : isWarning
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {item.status}
                    </span>
                  </td>

                  <td className="px-4 py-4 font-mono font-bold">
                    {item.recommendedOrder > 0 ? (
                      <span className="text-rose-400">{item.recommendedOrder} units</span>
                    ) : (
                      <span className="text-slate-500">0</span>
                    )}
                  </td>

                  <td className="px-5 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => onOpenExplain(item)}
                        className="px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-[11px] font-medium transition-colors"
                        title="AI Analysis"
                      >
                        AI Why?
                      </button>

                      <button
                        onClick={() => onOpenPurchaseOrder(item)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm ${
                          isCritical
                            ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                            : isWarning
                            ? 'bg-amber-600 hover:bg-amber-500 text-white'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                        }`}
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>Order</span>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
