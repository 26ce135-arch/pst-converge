import React from 'react';
import { AlertTriangle, ShoppingCart, ArrowRight } from 'lucide-react';
import { InventoryItem } from '../../types';

interface InventoryAlertCardProps {
  criticalItem?: InventoryItem;
  onOpenPurchaseOrder: (item: InventoryItem) => void;
}

export const InventoryAlertCard: React.FC<InventoryAlertCardProps> = ({
  criticalItem,
  onOpenPurchaseOrder,
}) => {
  if (!criticalItem) return null;

  return (
    <div className="glass-card rounded-2xl p-5 border border-rose-500/40 bg-gradient-to-r from-rose-950/30 via-slate-900/60 to-slate-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-start gap-3.5">
        <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 shrink-0">
          <AlertTriangle className="w-5 h-5 animate-pulse" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-rose-400">
              {criticalItem.product.toUpperCase()} INVENTORY ALERT
            </span>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300">
              {criticalItem.daysRemaining} Days Runway
            </span>
          </div>
          <p className="text-sm font-semibold text-white mt-1">
            &ldquo;{criticalItem.product} inventory is below the predicted reorder point ({criticalItem.currentStock} &lt; {criticalItem.reorderPoint} units).&rdquo;
          </p>
          <p className="text-xs text-slate-300 mt-1">
            <strong>Recommended Action:</strong> Order {criticalItem.recommendedOrder} units. Reason: Forecasted demand exceeds available inventory after accounting for lead time and safety stock.
          </p>
        </div>
      </div>

      <button
        onClick={() => onOpenPurchaseOrder(criticalItem)}
        className="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 transition-all flex items-center justify-center gap-2 shrink-0 shadow-lg shadow-rose-600/30"
      >
        <ShoppingCart className="w-4 h-4" />
        <span>Generate Purchase Order</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
