import React from 'react';
import { Package, CheckCircle2, AlertOctagon, Route, IndianRupee, Target } from 'lucide-react';
import { StatCard } from '../common/StatCard';
import { NavTab } from '../layout/Sidebar';
import { formatCurrency } from '../../utils/formatters';

interface KpiGridProps {
  onNavigate: (tab: NavTab) => void;
  currencySymbol?: string;
  totalOrdersCount?: number;
  inventoryAlertsCount?: number;
}

export const KpiGrid: React.FC<KpiGridProps> = ({
  onNavigate,
  currencySymbol = '₹',
  totalOrdersCount = 248,
  inventoryAlertsCount = 7,
}) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
      {/* 1. Total Orders */}
      <StatCard
        title="Total Orders"
        value={totalOrdersCount}
        subtitle="50 active dispatches today"
        icon={Package}
        trend={{ value: '+14% vs last week', isPositive: true }}
        accentColor="indigo"
        onClick={() => onNavigate('orders')}
      />

      {/* 2. On-Time Delivery */}
      <StatCard
        title="On-Time Delivery"
        value="94.2%"
        subtitle="Target: ≥ 92.0% SLA"
        icon={CheckCircle2}
        trend={{ value: '+2.1% SLA gain', isPositive: true }}
        accentColor="emerald"
        onClick={() => onNavigate('delivery')}
      />

      {/* 3. Inventory Alerts */}
      <StatCard
        title="Inventory Alerts"
        value={inventoryAlertsCount}
        subtitle="Steel (Critical), Bricks, Tiles"
        icon={AlertOctagon}
        trend={{ value: 'Action required', isPositive: false }}
        accentColor="rose"
        onClick={() => onNavigate('inventory')}
      />

      {/* 4. Distance Saved */}
      <StatCard
        title="Distance Saved"
        value="128 km"
        subtitle="Cumulative weekly 2-Opt"
        icon={Route}
        trend={{ value: '-16.8% per circuit', isPositive: true }}
        accentColor="blue"
        onClick={() => onNavigate('route')}
      />

      {/* 5. Estimated Cost Saved */}
      <StatCard
        title="Est. Cost Saved"
        value={formatCurrency(18450, currencySymbol)}
        subtitle="Fuel & transit idle cut"
        icon={IndianRupee}
        trend={{ value: '₹105 / single run', isPositive: true }}
        accentColor="purple"
        onClick={() => onNavigate('route')}
      />

      {/* 6. Forecast Accuracy */}
      <StatCard
        title="Forecast Accuracy"
        value="91.6%"
        subtitle="30-day rolling MAPE"
        icon={Target}
        trend={{ value: 'High Confidence', isPositive: true }}
        accentColor="amber"
        onClick={() => onNavigate('demand')}
      />
    </div>
  );
};
