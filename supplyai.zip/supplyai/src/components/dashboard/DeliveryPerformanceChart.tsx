import React from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from 'recharts';
import { CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

export const DeliveryPerformanceChart: React.FC = () => {
  const data = [
    { name: 'On-Time Deliveries', value: 94.2, color: '#10b981' },
    { name: 'Transit Delayed', value: 3.8, color: '#f59e0b' },
    { name: 'Dock Rescheduled', value: 2.0, color: '#ef4444' },
  ];

  return (
    <div className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <span>Delivery Performance</span>
            <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-normal">
              94.2% On-Time
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">SLA reliability across regional fleets</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 py-2">
        <div className="w-44 h-44 relative flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={70}
                paddingAngle={4}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  fontSize: '12px',
                  color: '#f8fafc',
                }}
                formatter={(val: number) => [`${val}%`, 'Proportion']}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute text-center">
            <span className="text-xl font-black text-white font-mono">94.2%</span>
            <span className="block text-[10px] text-emerald-400 font-semibold uppercase">On-Time</span>
          </div>
        </div>

        <div className="flex-1 space-y-2.5 w-full">
          <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
            <div className="flex items-center gap-2 text-emerald-300 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>On-Time</span>
            </div>
            <span className="font-mono font-bold text-emerald-400">94.2% (234)</span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
            <div className="flex items-center gap-2 text-amber-300 font-medium">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Minor Delay</span>
            </div>
            <span className="font-mono font-bold text-amber-400">3.8% (9)</span>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs">
            <div className="flex items-center gap-2 text-rose-300 font-medium">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>Rescheduled</span>
            </div>
            <span className="font-mono font-bold text-rose-400">2.0% (5)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
