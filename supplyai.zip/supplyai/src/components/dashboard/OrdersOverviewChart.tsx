import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

export const OrdersOverviewChart: React.FC = () => {
  // 30 days aggregated order volume demo distribution
  const data = [
    { day: 'W1-Mon', orders: 8 },
    { day: 'W1-Tue', orders: 11 },
    { day: 'W1-Wed', orders: 14 },
    { day: 'W1-Thu', orders: 12 },
    { day: 'W1-Fri', orders: 16 },
    { day: 'W2-Mon', orders: 9 },
    { day: 'W2-Tue', orders: 13 },
    { day: 'W2-Wed', orders: 15 },
    { day: 'W2-Thu', orders: 18 },
    { day: 'W2-Fri', orders: 20 },
    { day: 'W3-Mon', orders: 12 },
    { day: 'W3-Tue', orders: 14 },
    { day: 'W3-Wed', orders: 19 },
    { day: 'W3-Thu', orders: 17 },
    { day: 'W3-Fri', orders: 22 },
    { day: 'W4-Mon', orders: 15 },
    { day: 'W4-Tue', orders: 18 },
    { day: 'W4-Wed', orders: 21 },
    { day: 'W4-Thu', orders: 24 },
    { day: 'W4-Fri', orders: 26 },
  ];

  return (
    <div className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <span>Orders – Last 30 Days</span>
            <span className="px-2 py-0.5 rounded text-[10px] bg-sky-500/10 text-sky-400 border border-sky-500/20 font-normal">
              248 Total
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Aggregated dispatch throughput</p>
        </div>
        <span className="text-xs font-mono font-semibold text-emerald-400">+14.2% MoM</span>
      </div>

      <div className="h-60 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis dataKey="day" stroke="#64748b" fontSize={9} tickLine={false} interval={2} />
            <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0f172a',
                borderColor: '#334155',
                borderRadius: '0.75rem',
                fontSize: '12px',
                color: '#f8fafc',
              }}
              formatter={(val: number) => [`${val} orders`, 'Dispatches']}
            />
            <Bar dataKey="orders" fill="#38bdf8" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
