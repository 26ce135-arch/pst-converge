import React from 'react';
import { Route, TrendingDown, Clock, Target, ShieldCheck, Sparkles } from 'lucide-react';

export const ImpactSection: React.FC = () => {
  const impacts = [
    {
      metric: '16.8%',
      label: 'Transportation Distance Saved',
      description: 'Achieved via 2-Opt TSP heuristic routing',
      icon: Route,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/20',
    },
    {
      metric: '12.0%',
      label: 'Estimated Logistics Cost Reduction',
      description: 'Reduced mileage and idle fuel consumption',
      icon: TrendingDown,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/10',
      borderColor: 'border-indigo-500/20',
    },
    {
      metric: '94.2%',
      label: 'On-Time Delivery Success Rate',
      description: 'Proactive corridor & window risk detection',
      icon: Clock,
      color: 'text-sky-400',
      bgColor: 'bg-sky-500/10',
      borderColor: 'border-sky-500/20',
    },
    {
      metric: '91.6%',
      label: 'Demand Forecast Accuracy',
      description: 'Decomposed 30-day seasonal moving average',
      icon: Target,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10',
      borderColor: 'border-purple-500/20',
    },
    {
      metric: '0.0%',
      label: 'Active Stockout Disruptions',
      description: 'Protected by automated reorder point buffers',
      icon: ShieldCheck,
      color: 'text-teal-400',
      bgColor: 'bg-teal-500/10',
      borderColor: 'border-teal-500/20',
    },
  ];

  return (
    <div className="glass-card rounded-2xl p-6 border border-slate-800 relative overflow-hidden">
      {/* Background ambient gradient */}
      <div className="absolute top-0 right-0 w-80 h-32 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-md bg-indigo-500/20 text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </span>
            <h2 className="text-sm font-bold uppercase tracking-wider text-white">
              Demonstrated System Impact & ROI
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Quantifiable supply chain efficiency gains across demand, inventory, and fleet dispatch
          </p>
        </div>

        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 text-[10px] font-semibold text-slate-300">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
          <span>Demo Simulation Benchmark</span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 mt-5">
        {impacts.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className={`p-4 rounded-xl ${item.bgColor} border ${item.borderColor} transition-transform hover:-translate-y-1 duration-200`}
            >
              <div className="flex items-center justify-between mb-2">
                <Icon className={`w-4 h-4 ${item.color}`} />
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                  Est. Impact
                </span>
              </div>
              <div className={`text-2xl font-black tracking-tight ${item.color} font-mono`}>
                {item.metric}
              </div>
              <div className="text-xs font-semibold text-white mt-1 line-clamp-1">{item.label}</div>
              <div className="text-[11px] text-slate-400 mt-1 leading-snug line-clamp-2">
                {item.description}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
