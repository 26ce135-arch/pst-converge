import React from 'react';
import { Sparkles, ArrowRight, AlertTriangle, TrendingUp, CheckCircle, Boxes } from 'lucide-react';
import { NavTab } from '../layout/Sidebar';

interface AiInsightsPanelProps {
  onNavigate: (tab: NavTab) => void;
  onOpenExplainModal: () => void;
}

export const AiInsightsPanel: React.FC<AiInsightsPanelProps> = ({
  onNavigate,
  onOpenExplainModal,
}) => {
  return (
    <div className="glass-card rounded-2xl p-6 border border-indigo-500/30 bg-gradient-to-br from-slate-900/90 via-indigo-950/20 to-slate-900/90 relative overflow-hidden shadow-xl">
      {/* Glow highlight */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                Active Intelligence
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Confidence 91%
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mt-0.5">Real-time Cross-Pillar AI Insights</h3>
          </div>
        </div>

        <button
          onClick={onOpenExplainModal}
          className="text-xs text-indigo-300 hover:text-white flex items-center gap-1 font-medium underline underline-offset-4 transition-colors"
        >
          View Full AI Explainability Matrix
        </button>
      </div>

      {/* Grid of 3 core blocks: Insight, Recommendation, Risk */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">
        {/* 1. AI INSIGHT */}
        <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 hover:border-indigo-500/40 transition-colors">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-400 uppercase tracking-wider mb-2">
            <TrendingUp className="w-4 h-4" />
            <span>AI INSIGHT</span>
          </div>
          <p className="text-sm font-semibold text-white leading-relaxed">
            &ldquo;Steel demand is predicted to increase by 18% over the next 7 days.&rdquo;
          </p>
          <p className="text-xs text-slate-400 mt-2">
            Driven by 3 foundation pour milestones starting mid-week in eastern NCR corridors.
          </p>
        </div>

        {/* 2. RECOMMENDATION */}
        <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 hover:border-emerald-500/40 transition-colors">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">
            <CheckCircle className="w-4 h-4" />
            <span>RECOMMENDATION</span>
          </div>
          <p className="text-sm font-semibold text-white leading-relaxed">
            &ldquo;Increase steel inventory by approximately 250 units.&rdquo;
          </p>
          <p className="text-xs text-slate-400 mt-2">
            Generates buffer before 4-day lead time expires, preventing projected stockout.
          </p>
        </div>

        {/* 3. RISK */}
        <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 hover:border-amber-500/40 transition-colors">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
            <AlertTriangle className="w-4 h-4" />
            <span>CRITICAL RISK</span>
          </div>
          <p className="text-sm font-semibold text-white leading-relaxed">
            &ldquo;Warehouse B may experience a stock shortage within 4 days.&rdquo;
          </p>
          <p className="text-xs text-slate-400 mt-2">
            Current buffer covers 2 operating days against high-velocity contractor consumption.
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-end gap-3">
        <button
          onClick={() => onNavigate('demand')}
          className="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-2 transition-all"
        >
          <TrendingUp className="w-4 h-4 text-indigo-400" />
          <span>View Forecast</span>
        </button>

        <button
          onClick={() => onNavigate('inventory')}
          className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all"
        >
          <Boxes className="w-4 h-4" />
          <span>Review Inventory</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
