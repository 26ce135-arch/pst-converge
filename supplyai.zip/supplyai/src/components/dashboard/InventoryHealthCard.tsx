import React from 'react';
import { InventoryItem } from '../../types';
import { Boxes, AlertOctagon } from 'lucide-react';
import { NavTab } from '../layout/Sidebar';

interface InventoryHealthCardProps {
  inventory: InventoryItem[];
  onNavigate: (tab: NavTab) => void;
}

export const InventoryHealthCard: React.FC<InventoryHealthCardProps> = ({
  inventory,
  onNavigate,
}) => {
  return (
    <div className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <span>Inventory Health Status</span>
            <span className="px-2 py-0.5 rounded text-[10px] bg-rose-500/10 text-rose-400 border border-rose-500/20 font-normal">
              1 Critical / 2 Warning
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Stock vs Reorder Point (ROP) thresholds</p>
        </div>

        <button
          onClick={() => onNavigate('inventory')}
          className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 transition-colors"
        >
          Manage All &rarr;
        </button>
      </div>

      <div className="space-y-3 mt-1">
        {inventory.map((item) => {
          const ratio = Math.min(100, Math.round((item.currentStock / item.reorderPoint) * 100));
          const isCritical = item.status === 'Critical';
          const isWarning = item.status === 'Warning';

          return (
            <div key={item.id} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white">{item.product}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                      isCritical
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : isWarning
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400">
                  <span className="text-white font-mono font-medium">{item.currentStock}</span> /{' '}
                  <span className="font-mono">{item.reorderPoint} ROP</span> ({item.daysRemaining}d left)
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    isCritical ? 'bg-rose-500' : isWarning ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.max(8, ratio)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
