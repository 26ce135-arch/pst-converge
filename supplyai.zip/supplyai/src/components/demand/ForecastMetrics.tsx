import React from 'react';
import { ProductForecast } from '../../types';
import { Activity, TrendingUp, ShieldCheck, Calendar } from 'lucide-react';
import { formatPercent } from '../../utils/formatters';

interface ForecastMetricsProps {
  forecast: ProductForecast;
}

export const ForecastMetrics: React.FC<ForecastMetricsProps> = ({ forecast }) => {
  const isPositive = forecast.growthPct >= 0;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      {/* 1. Current Average Demand */}
      <div className="glass-card rounded-2xl p-4 sm:p-5 border border-slate-800">
        <div className="flex items-center justify-between text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Current Avg Demand</span>
          <Activity className="w-4 h-4 text-indigo-400" />
        </div>
        <div className="text-2xl font-black text-white font-mono">
          {forecast.currentAvgDemand} <span className="text-xs font-sans text-slate-400 font-normal">units/day</span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Based on trailing 30-day order velocity</p>
      </div>

      {/* 2. Predicted Demand */}
      <div className="glass-card rounded-2xl p-4 sm:p-5 border border-slate-800">
        <div className="flex items-center justify-between text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Predicted Demand</span>
          <TrendingUp className="w-4 h-4 text-sky-400" />
        </div>
        <div className="text-2xl font-black text-white font-mono">
          {forecast.predictedAvgDemand} <span className="text-xs font-sans text-slate-400 font-normal">units/day</span>
        </div>
        <p className="text-[11px] text-sky-300 mt-1">Projected average for next {forecast.periodDays} days</p>
      </div>

      {/* 3. Growth % */}
      <div className="glass-card rounded-2xl p-4 sm:p-5 border border-slate-800">
        <div className="flex items-center justify-between text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Expected Growth</span>
          <span className="text-xs font-bold text-emerald-400">{forecast.periodDays}D Horizon</span>
        </div>
        <div className="flex items-baseline gap-2">
          <span className={`text-2xl font-black font-mono ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
            {formatPercent(forecast.growthPct, true)}
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Decomposed weekly trend slope</p>
      </div>

      {/* 4. Confidence % */}
      <div className="glass-card rounded-2xl p-4 sm:p-5 border border-slate-800">
        <div className="flex items-center justify-between text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Confidence Level</span>
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-2xl font-black text-white font-mono">{forecast.confidencePct}%</span>
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            High Reliability
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">Std error bounds within ±6.2%</p>
      </div>
    </div>
  );
};
