import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ReferenceLine,
} from 'recharts';
import { ProductForecast } from '../../types';

interface ForecastChartProps {
  forecast: ProductForecast;
}

export const ForecastChart: React.FC<ForecastChartProps> = ({ forecast }) => {
  const data = forecast.dataPoints.map((p) => ({
    date: p.date,
    actual: p.actualDemand !== undefined ? p.actualDemand : null,
    predicted: p.predictedDemand !== undefined ? p.predictedDemand : null,
    upperBound: p.confidenceUpper !== undefined ? p.confidenceUpper : null,
    lowerBound: p.confidenceLower !== undefined ? p.confidenceLower : null,
  }));

  return (
    <div className="glass-card rounded-2xl p-5 border border-slate-800">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <span>Historical Actual vs Predictive Demand Trajectory</span>
            <span className="px-2 py-0.5 rounded text-[10px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-normal">
              {forecast.product}
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            30-day actual history spliced with {forecast.periodDays}-day forward projected demand
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-3 h-0.5 bg-slate-400 rounded-full" />
            <span>Actual Demand</span>
          </div>
          <div className="flex items-center gap-1.5 text-indigo-400">
            <span className="w-3 h-0.5 bg-indigo-500 rounded-full" />
            <span>Predicted Demand</span>
          </div>
        </div>
      </div>

      <div className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 15, right: 15, left: -15, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis dataKey="date" stroke="#64748b" fontSize={10} tickLine={false} interval={4} />
            <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0f172a',
                borderColor: '#334155',
                borderRadius: '0.75rem',
                fontSize: '12px',
                color: '#f8fafc',
              }}
            />
            <ReferenceLine x="Today" stroke="#475569" strokeDasharray="3 3" label={{ value: 'Forecast Horizon', fill: '#94a3b8', fontSize: 10 }} />
            <Line
              type="monotone"
              dataKey="actual"
              stroke="#94a3b8"
              strokeWidth={2}
              dot={{ r: 2, fill: '#94a3b8' }}
              name="Actual Demand"
              connectNulls={false}
            />
            <Line
              type="monotone"
              dataKey="predicted"
              stroke="#6366f1"
              strokeWidth={3}
              strokeDasharray="5 3"
              dot={{ r: 3, fill: '#818cf8' }}
              name="Predicted Demand"
              connectNulls={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
