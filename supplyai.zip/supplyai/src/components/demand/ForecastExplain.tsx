import React from 'react';
import { ProductForecast } from '../../types';
import { HelpCircle, Sparkles, TrendingUp, Calendar, AlertCircle } from 'lucide-react';

interface ForecastExplainProps {
  forecast: ProductForecast;
}

export const ForecastExplain: React.FC<ForecastExplainProps> = ({ forecast }) => {
  return (
    <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
              Explainable Analytics Framework
            </span>
            <h3 className="text-base font-bold text-white">WHY IS DEMAND CHANGING?</h3>
          </div>
        </div>

        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 border border-slate-700/80 text-xs font-semibold text-slate-300">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>AI Predictive Analytics Demo</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Core Heuristic Explanation */}
        <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-400 uppercase tracking-wider mb-2">
            <Sparkles className="w-4 h-4" /> Root Heuristic
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-medium">
            &ldquo;{forecast.explanation}&rdquo;
          </p>
        </div>

        {/* Order Trend Velocity */}
        <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">
            <TrendingUp className="w-4 h-4" /> Trend Driver
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {forecast.trendReason}
          </p>
        </div>

        {/* Seasonality Pattern */}
        <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60">
          <div className="flex items-center gap-2 text-xs font-bold text-sky-400 uppercase tracking-wider mb-2">
            <Calendar className="w-4 h-4" /> Weekly Seasonality
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {forecast.seasonalPattern}
          </p>
        </div>
      </div>

      {/* Transparency Note */}
      <div className="p-3 rounded-xl bg-indigo-950/20 border border-indigo-500/20 flex items-start gap-2.5 text-xs text-indigo-200">
        <AlertCircle className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong>Transparency Notice:</strong> This forecast is powered by an explainable 7-day weighted moving average with day-of-week seasonality factors. In production, this service can easily connect to trained ML pipelines (e.g. Prophet, ARIMA, or PyTorch LSTM).
        </p>
      </div>
    </div>
  );
};
