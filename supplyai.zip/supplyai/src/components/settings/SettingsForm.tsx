import React, { useState } from 'react';
import { AppSettings } from '../../types';
import { Save, CheckCircle2, Sliders, Building, MapPin, Gauge, Clock, Shield } from 'lucide-react';

interface SettingsFormProps {
  settings: AppSettings;
  onSave: (settings: AppSettings) => void;
}

export const SettingsForm: React.FC<SettingsFormProps> = ({ settings, onSave }) => {
  const [form, setForm] = useState<AppSettings>(settings);
  const [savedToast, setSavedToast] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(form);
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  return (
    <div className="glass-card rounded-2xl border border-slate-800 p-6 shadow-xl max-w-3xl">
      <div className="flex items-center justify-between pb-5 border-b border-slate-800 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">System & Algorithm Parameters</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Tune simulation coefficients, default fleet speeds, and safety factors
            </p>
          </div>
        </div>

        {savedToast && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-semibold border border-emerald-500/30 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings Saved</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Company Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-indigo-400" /> Company Name
            </label>
            <input
              type="text"
              value={form.companyName}
              onChange={(e) => setForm({ ...form, companyName: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              required
            />
          </div>

          {/* Default Warehouse */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-indigo-400" /> Default Warehouse Hub
            </label>
            <input
              type="text"
              value={form.defaultWarehouse}
              onChange={(e) => setForm({ ...form, defaultWarehouse: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              required
            />
          </div>

          {/* Currency */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Operating Currency
            </label>
            <select
              value={form.currency}
              onChange={(e) => {
                const cur = e.target.value;
                setForm({
                  ...form,
                  currency: cur,
                  currencySymbol: cur === 'INR' ? '₹' : cur === 'USD' ? '$' : '€',
                });
              }}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
            >
              <option value="INR">INR (₹) - Indian Rupee (Default)</option>
              <option value="USD">USD ($) - US Dollar</option>
              <option value="EUR">EUR (€) - Euro</option>
            </select>
          </div>

          {/* Average Vehicle Speed */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-indigo-400" /> Avg Vehicle Speed (km/h)
            </label>
            <input
              type="number"
              min="15"
              max="90"
              value={form.avgVehicleSpeedKmh}
              onChange={(e) => setForm({ ...form, avgVehicleSpeedKmh: parseInt(e.target.value) || 35 })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              required
            />
          </div>

          {/* Lead Time Days */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-indigo-400" /> Default Lead Time (Days)
            </label>
            <input
              type="number"
              min="1"
              max="30"
              value={form.defaultLeadTimeDays}
              onChange={(e) => setForm({ ...form, defaultLeadTimeDays: parseInt(e.target.value) || 3 })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              required
            />
          </div>

          {/* Safety Stock Factor */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-indigo-400" /> Safety Stock Multiplier (Z-Factor)
            </label>
            <input
              type="number"
              step="0.1"
              min="1.0"
              max="3.0"
              value={form.safetyStockFactor}
              onChange={(e) => setForm({ ...form, safetyStockFactor: parseFloat(e.target.value) || 1.5 })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              required
            />
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800 flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-indigo-600 hover:bg-indigo-500 transition-all flex items-center gap-2 shadow-lg shadow-indigo-600/30"
          >
            <Save className="w-4 h-4" />
            <span>Save Configuration</span>
          </button>
        </div>
      </form>
    </div>
  );
};
