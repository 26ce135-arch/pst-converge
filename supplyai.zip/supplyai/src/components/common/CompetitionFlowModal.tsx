import React from 'react';
import { X, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';
import { NavTab } from '../layout/Sidebar';

interface CompetitionFlowModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateStep: (tab: NavTab) => void;
}

export const CompetitionFlowModal: React.FC<CompetitionFlowModalProps> = ({
  isOpen,
  onClose,
  onNavigateStep,
}) => {
  if (!isOpen) return null;

  const steps = [
    {
      step: 1,
      tab: 'dashboard' as NavTab,
      title: 'Dashboard Briefing',
      action: 'Examine executive telemetry & notice AI Insight: "Steel demand +18% in 7 days".',
    },
    {
      step: 2,
      tab: 'demand' as NavTab,
      title: 'Demand Forecast',
      action: 'Select Steel. Review Recharts trajectory curve and click "Generate New Forecast".',
    },
    {
      step: 3,
      tab: 'inventory' as NavTab,
      title: 'Inventory Intelligence',
      action: 'Inspect Steel marked as "Critical" (2 days left). Open "Generate Purchase Order" for 250 units.',
    },
    {
      step: 4,
      tab: 'route' as NavTab,
      title: 'Route Optimizer',
      action: 'Click "OPTIMIZE ROUTE". Watch 2-Opt animation: 51.2 km → 42.6 km (16.8% saved).',
    },
    {
      step: 5,
      tab: 'delivery' as NavTab,
      title: 'Delivery Prediction',
      action: 'Inspect ORD-1003 delay risk prediction (Warehouse C). Click "Move to Route 2".',
    },
    {
      step: 6,
      tab: 'assistant' as NavTab,
      title: 'AI Assistant',
      action: 'Ask: "How can I reduce my supply-chain costs?". Read comprehensive 4-pillar analysis.',
    },
    {
      step: 7,
      tab: 'dashboard' as NavTab,
      title: 'Executive Impact',
      action: 'Return to Dashboard. Highlight 16.8% distance cut, 12% cost cut, and 94.2% on-time delivery.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-2xl glass-card border border-indigo-500/40 p-6 shadow-2xl bg-slate-900/95 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs uppercase font-semibold tracking-wider text-indigo-400">
                Official Pitch Script
              </span>
              <h3 className="text-lg font-bold text-white">3-Minute Competition Demo Flow</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-3">
          {steps.map((s) => (
            <div
              key={s.step}
              className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center justify-between gap-3 hover:border-indigo-500/40 transition-colors"
            >
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  {s.step}
                </span>
                <div>
                  <h4 className="text-xs font-bold text-white">{s.title}</h4>
                  <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">{s.action}</p>
                </div>
              </div>

              <button
                onClick={() => {
                  onNavigateStep(s.tab);
                  onClose();
                }}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold flex items-center gap-1 shrink-0 transition-colors"
              >
                <span>Jump</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
