import React, { useState } from 'react';
import { X, PlusCircle, Building, Package, Layers, Navigation, AlertCircle } from 'lucide-react';
import { Order, OrderPriority, ProductType } from '../../types';
import { WAREHOUSE_LOCATIONS } from '../../data/warehouses';

interface AddOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddOrder: (newOrder: Partial<Order>) => void;
}

export const AddOrderModal: React.FC<AddOrderModalProps> = ({ isOpen, onClose, onAddOrder }) => {
  const [customer, setCustomer] = useState('');
  const [product, setProduct] = useState<ProductType>('Steel');
  const [quantity, setQuantity] = useState(100);
  const [priority, setPriority] = useState<OrderPriority>('High');
  const [destinationId, setDestinationId] = useState('loc-wh-a');
  const [formError, setFormError] = useState('');

  if (!isOpen) return null;

  const warehouses = WAREHOUSE_LOCATIONS.filter((w) => w.type === 'warehouse');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer.trim()) {
      setFormError('Please enter the customer or contractor name.');
      return;
    }
    if (quantity <= 0) {
      setFormError('Order quantity must be greater than zero.');
      return;
    }

    const selectedWh = warehouses.find((w) => w.id === destinationId) || warehouses[0];

    onAddOrder({
      customer: customer.trim(),
      product,
      quantity,
      priority,
      destination: selectedWh.name.split(' (')[0],
      destinationWarehouseId: selectedWh.id,
      distanceKm: selectedWh.id === 'loc-wh-a' ? 8.2 : selectedWh.id === 'loc-wh-b' ? 12.4 : 18.1,
      vehicle: 'Truck 01',
      eta: '16:45',
      risk: priority === 'High' ? 'Medium' : 'Low',
      status: 'Pending',
      orderDate: 'Just now',
      deliveryWindow: selectedWh.deliveryWindow,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-2xl glass-card border border-indigo-500/30 p-6 shadow-2xl bg-slate-900/95">
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs uppercase font-semibold tracking-wider text-indigo-400">
                Logistics Dispatch
              </span>
              <h3 className="text-lg font-bold text-white">Create New Consignment</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {formError && (
          <div className="mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Customer */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-indigo-400" /> Customer / Project Name
            </label>
            <input
              type="text"
              placeholder="e.g. L&T Heavy Infrastructure, DLF Phase 5"
              value={customer}
              onChange={(e) => {
                setCustomer(e.target.value);
                setFormError('');
              }}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
              required
            />
          </div>

          {/* Product & Quantity */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-indigo-400" /> Product
              </label>
              <select
                value={product}
                onChange={(e) => setProduct(e.target.value as ProductType)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="Cement">Cement</option>
                <option value="Steel">Steel</option>
                <option value="Bricks">Bricks</option>
                <option value="Pipes">Pipes</option>
                <option value="Tiles">Tiles</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-400" /> Quantity (Units)
              </label>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => {
                  setQuantity(parseInt(e.target.value) || 0);
                  setFormError('');
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
                required
              />
            </div>
          </div>

          {/* Priority & Destination */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Delivery Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as OrderPriority)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                <option value="High">High (Express)</option>
                <option value="Medium">Medium (Standard)</option>
                <option value="Low">Low (Flexible)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Navigation className="w-3.5 h-3.5 text-indigo-400" /> Destination
              </label>
              <select
                value={destinationId}
                onChange={(e) => setDestinationId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                {warehouses.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.code} - {w.name.split(' (')[0]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/30"
            >
              Register Consignment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
