import React, { useState } from 'react';
import { X, ShoppingBag, Truck, Calendar, Building2, CheckCircle, IndianRupee } from 'lucide-react';
import { ProductType, InventoryItem } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface PurchaseOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: InventoryItem | null;
  onConfirm: (po: {
    product: ProductType;
    quantity: number;
    supplier: string;
    expectedDelivery: string;
    estimatedCost: number;
  }) => void;
  currencySymbol?: string;
}

export const PurchaseOrderModal: React.FC<PurchaseOrderModalProps> = ({
  isOpen,
  onClose,
  item,
  onConfirm,
  currencySymbol = '₹',
}) => {
  if (!isOpen || !item) return null;

  const defaultQuantity = item.recommendedOrder > 0 ? item.recommendedOrder : 100;
  const [quantity, setQuantity] = useState<number>(defaultQuantity);
  const [supplier, setSupplier] = useState<string>(item.supplier);

  // Delivery date calculated from lead time
  const leadTimeDays = item.leadTimeDays || 3;
  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + leadTimeDays);
  const formattedDelivery = deliveryDate.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const estimatedCost = (quantity || 0) * item.unitPrice;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quantity <= 0) return;

    onConfirm({
      product: item.product,
      quantity,
      supplier,
      expectedDelivery: formattedDelivery,
      estimatedCost,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-2xl glass-card border border-indigo-500/30 p-6 shadow-2xl bg-slate-900/95">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-semibold tracking-wider text-indigo-400">
                  Procurement Gateway
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-indigo-500/20 text-indigo-300">
                  PO Draft
                </span>
              </div>
              <h3 className="text-lg font-bold text-white mt-0.5">Generate Purchase Order</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Supplier */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-indigo-400" /> Supplier
            </label>
            <input
              type="text"
              value={supplier}
              onChange={(e) => setSupplier(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
              required
            />
          </div>

          {/* Product & Current Status */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-indigo-400" /> Product
              </label>
              <div className="px-3.5 py-2.5 rounded-xl bg-slate-800/40 border border-slate-700/60 text-white font-semibold text-sm">
                {item.product}
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Current Stock / ROP
              </label>
              <div className="px-3.5 py-2.5 rounded-xl bg-slate-800/40 border border-slate-700/60 text-slate-300 text-sm">
                <span className="font-semibold text-white">{item.currentStock}</span> / {item.reorderPoint} units
              </div>
            </div>
          </div>

          {/* Quantity (Editable) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Order Quantity (Units)
              </label>
              <span className="text-[11px] text-indigo-400 font-medium">
                AI Recommended: {item.recommendedOrder > 0 ? item.recommendedOrder : 100} units
              </span>
            </div>
            <input
              type="number"
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-base font-semibold focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
              required
            />
          </div>

          {/* Delivery & Cost Summary */}
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" /> Expected Delivery
              </span>
              <span className="text-white font-medium">
                {formattedDelivery} ({leadTimeDays} days lead time)
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5 text-slate-400" /> Unit Price
              </span>
              <span className="text-white font-mono">{formatCurrency(item.unitPrice, currencySymbol)}</span>
            </div>
            <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">Estimated Total Cost</span>
              <span className="text-base font-bold text-emerald-400 font-mono">
                {formatCurrency(estimatedCost, currencySymbol)}
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-3 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-all flex items-center gap-2 shadow-lg shadow-indigo-600/30"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Confirm & Dispatch PO</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
