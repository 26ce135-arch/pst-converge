import React from 'react';
import { X, Sparkles, ShieldCheck, HelpCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { AiExplainabilityData } from '../../types';

interface AiExplainModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: AiExplainabilityData | null;
  onApplyAction?: () => void;
  actionButtonLabel?: string;
}

export const AiExplainModal: React.FC<AiExplainModalProps> = ({
  isOpen,
  onClose,
  data,
  onApplyAction,
  actionButtonLabel = 'Execute Recommended Action',
}) => {
  if (!isOpen || !data) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl rounded-2xl glass-card border border-indigo-500/30 p-6 shadow-2xl bg-slate-900/95 overflow-hidden">
        {/* Glow decoration */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-semibold tracking-wider text-indigo-400">
                  AI Explainability Matrix
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Audited Heuristic
                </span>
              </div>
              <h3 className="text-lg font-bold text-white mt-0.5">{data.title}</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Matrix */}
        <div className="mt-5 space-y-4">
          {/* 1. Prediction */}
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-1">
              <span className="flex items-center gap-1.5 text-indigo-300">
                <Sparkles className="w-3.5 h-3.5" /> PREDICTION
              </span>
              {data.metric && <span className="text-white font-mono">{data.metric}</span>}
            </div>
            <p className="text-sm font-semibold text-white">{data.prediction}</p>
          </div>

          {/* 2. Confidence */}
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-1.5">
              <span className="flex items-center gap-1.5 text-emerald-300">
                <ShieldCheck className="w-3.5 h-3.5" /> CONFIDENCE SCORE
              </span>
              <span className="text-emerald-400 font-bold">{data.confidence}%</span>
            </div>
            <div className="w-full bg-slate-700/80 rounded-full h-2 overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-500 to-indigo-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, data.confidence)}%` }}
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Calculated via variance analysis against 30-day historical baseline and seasonal weights.
            </p>
          </div>

          {/* 3. Reason / Why */}
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-300 mb-1">
              <HelpCircle className="w-3.5 h-3.5" /> WHY IS THIS OCCURRING?
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{data.why}</p>
          </div>

          {/* 4. Action */}
          <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-300 mb-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> RECOMMENDED ACTION
            </div>
            <p className="text-xs font-medium text-indigo-100 leading-relaxed">{data.action}</p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="mt-6 flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Close
          </button>
          {onApplyAction && (
            <button
              onClick={() => {
                onApplyAction();
                onClose();
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-all flex items-center gap-1.5 shadow-lg shadow-indigo-600/30"
            >
              <span>{actionButtonLabel}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
