import React, { useState } from 'react';
import { Sidebar, NavTab } from './Sidebar';
import { Header } from './Header';

interface MainLayoutProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onResetDemo: () => void;
  onOpenCompetitionFlow: () => void;
  inventoryAlertCount: number;
  deliveryRiskCount: number;
  children: React.ReactNode;
}

export const MainLayout: React.FC<MainLayoutProps> = ({
  activeTab,
  onSelectTab,
  onResetDemo,
  onOpenCompetitionFlow,
  inventoryAlertCount,
  deliveryRiskCount,
  children,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={onSelectTab}
        onResetDemo={onResetDemo}
        isOpenMobile={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        inventoryAlertCount={inventoryAlertCount}
        deliveryRiskCount={deliveryRiskCount}
      />

      {/* Main Content Area */}
      <div className="lg:pl-64 flex-1 flex flex-col min-w-0">
        <Header
          activeTab={activeTab}
          onOpenMobile={() => setMobileOpen(true)}
          onOpenCompetitionFlow={onOpenCompetitionFlow}
          inventoryAlertCount={inventoryAlertCount}
          deliveryRiskCount={deliveryRiskCount}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          {children}
        </main>
      </div>
    </div>
  );
};
