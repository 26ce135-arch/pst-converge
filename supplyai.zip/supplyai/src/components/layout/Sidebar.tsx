import React from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  Boxes,
  MapPin,
  Clock,
  Package,
  Bot,
  Settings,
  Sparkles,
  RotateCcw,
  Activity,
  Layers,
  ChevronRight,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'demand'
  | 'inventory'
  | 'route'
  | 'delivery'
  | 'orders'
  | 'assistant'
  | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onResetDemo: () => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  inventoryAlertCount: number;
  deliveryRiskCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onResetDemo,
  isOpenMobile,
  onCloseMobile,
  inventoryAlertCount,
  deliveryRiskCount,
}) => {
  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'demand' as NavTab,
      label: 'Demand Forecast',
      icon: TrendingUp,
      badge: 'AI Heuristic',
    },
    {
      id: 'inventory' as NavTab,
      label: 'Inventory Intelligence',
      icon: Boxes,
      badge: inventoryAlertCount > 0 ? `${inventoryAlertCount} Alerts` : null,
      badgeColor: 'rose',
    },
    {
      id: 'route' as NavTab,
      label: 'Route Optimizer',
      icon: MapPin,
      badge: '2-Opt TSP',
    },
    {
      id: 'delivery' as NavTab,
      label: 'Delivery Prediction',
      icon: Clock,
      badge: deliveryRiskCount > 0 ? `${deliveryRiskCount} At Risk` : null,
      badgeColor: 'amber',
    },
    {
      id: 'orders' as NavTab,
      label: 'Orders',
      icon: Package,
      badge: '50 Active',
    },
    {
      id: 'assistant' as NavTab,
      label: 'AI Assistant',
      icon: Bot,
      highlight: true,
    },
    {
      id: 'settings' as NavTab,
      label: 'Settings',
      icon: Settings,
      badge: null,
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-[#0a0f1d] border-r border-slate-800/80 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 text-white shadow-lg shadow-indigo-500/20">
              <Layers className="w-5 h-5 text-white" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-[#0a0f1d]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-black tracking-tight text-white">SUPPLYAI</span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold tracking-widest bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 uppercase">
                  v2.4
                </span>
              </div>
              <p className="text-[11px] font-medium text-indigo-400/80 tracking-wide">
                Predict. Optimize. Deliver.
              </p>
            </div>
          </div>

          {/* AI Status & Demo Mode Indicator */}
          <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              <span className="text-[11px] font-medium text-emerald-400">AI System Online</span>
            </div>

            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-950/60 border border-indigo-800/60 text-[10px] font-semibold text-indigo-300">
              <Sparkles className="w-2.5 h-2.5 text-indigo-400" />
              <span>Demo Mode</span>
            </div>
          </div>
        </div>

        {/* Navigation items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : item.highlight
                    ? 'text-indigo-300 hover:text-white hover:bg-indigo-950/40 border border-indigo-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                      isActive ? 'text-white' : item.highlight ? 'text-indigo-400' : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.badge && !isActive && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        item.badgeColor === 'rose'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : item.badgeColor === 'amber'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {isActive && <ChevronRight className="w-3.5 h-3.5 text-indigo-200" />}
                </div>
              </button>
            );
          })}
        </nav>

        {/* Reset Demo Data & Competition Footer */}
        <div className="p-3.5 m-3 rounded-xl bg-slate-900/90 border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>State Store</span>
            <span className="font-mono text-[10px] text-slate-500">Local Active</span>
          </div>

          <button
            onClick={onResetDemo}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700/80 text-slate-300 hover:text-white text-xs font-medium transition-colors border border-slate-700/60"
            title="Reset all demo data back to default competition starting state"
          >
            <RotateCcw className="w-3.5 h-3.5 text-indigo-400" />
            <span>Reset Demo Data</span>
          </button>
        </div>
      </aside>
    </>
  );
};
