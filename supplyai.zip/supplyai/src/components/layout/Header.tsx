import React from 'react';
import { Menu, Sparkles, Bell, HelpCircle, CheckCircle, ShieldAlert } from 'lucide-react';
import { NavTab } from './Sidebar';

interface HeaderProps {
  activeTab: NavTab;
  onOpenMobile: () => void;
  onOpenCompetitionFlow: () => void;
  inventoryAlertCount: number;
  deliveryRiskCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenMobile,
  onOpenCompetitionFlow,
  inventoryAlertCount,
  deliveryRiskCount,
}) => {
  const titles: Record<NavTab, { title: string; subtitle: string }> = {
    dashboard: {
      title: 'Executive Logistics Command',
      subtitle: 'Real-time telemetry, KPI health, and predictive supply chain signals',
    },
    demand: {
      title: 'Demand Forecasting Intelligence',
      subtitle: 'Explainable moving-average and seasonal pattern projections',
    },
    inventory: {
      title: 'Inventory Intelligence & ROP',
      subtitle: 'Dynamic reorder point calculation, safety buffers, and PO generation',
    },
    route: {
      title: 'Route Optimizer (2-Opt TSP)',
      subtitle: 'Multi-node delivery circuit optimization and fuel savings analysis',
    },
    delivery: {
      title: 'Delivery Delay & ETA Prediction',
      subtitle: 'Risk matrix assessing transit corridors, fleet speed, and SLA windows',
    },
    orders: {
      title: 'Consignments & Orders',
      subtitle: 'Manage active customer dispatches across regional distribution nodes',
    },
    assistant: {
      title: 'SupplyAI Copilot Assistant',
      subtitle: 'Natural language analytical interface grounded in active supply data',
    },
    settings: {
      title: 'System Configuration',
      subtitle: 'Operational parameters, vehicle speeds, lead times, and currency formats',
    },
  };

  const current = titles[activeTab] || titles.dashboard;

  return (
    <header className="sticky top-0 z-30 h-16 bg-[#0a0f1d]/90 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-6 flex items-center justify-between">
      {/* Left Title & Mobile Toggle */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobile}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden transition-colors"
          aria-label="Open sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <span>{current.title}</span>
          </h1>
          <p className="text-[11px] text-slate-400 hidden sm:block">
            {current.subtitle}
          </p>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* 3-Minute Demo Flow Helper Button */}
        <button
          onClick={onOpenCompetitionFlow}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition-all border border-indigo-400/30"
          title="Interactive 3-Minute Competition Demo Walkthrough"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
          <span className="hidden md:inline">Competition Demo Flow</span>
          <span className="md:hidden">Demo Guide</span>
        </button>

        {/* Live Alerts Indicators */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 rounded-xl p-1">
          <div
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold ${
              inventoryAlertCount > 0 ? 'bg-rose-500/15 text-rose-400' : 'bg-slate-800 text-slate-400'
            }`}
            title={`${inventoryAlertCount} Inventory Reorder Alerts`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span className="text-[11px] font-mono">{inventoryAlertCount}</span>
          </div>

          <div
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-semibold ${
              deliveryRiskCount > 0 ? 'bg-amber-500/15 text-amber-400' : 'bg-slate-800 text-slate-400'
            }`}
            title={`${deliveryRiskCount} Delivery Risks Flagged`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span className="text-[11px] font-mono">{deliveryRiskCount}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
