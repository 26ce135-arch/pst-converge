import React from 'react';
import { AlertTriangle, Clock, ArrowRight, ShieldAlert, CheckCircle } from 'lucide-react';
import { Order } from '../../types';

interface DeliveryRiskCardProps {
  order1003?: Order;
  onApplyMitigation?: () => void;
}

export const DeliveryRiskCard: React.FC<DeliveryRiskCardProps> = ({
  order1003,
  onApplyMitigation,
}) => {
  return (
    <div className="glass-card rounded-2xl p-5 border border-amber-500/40 bg-gradient-to-r from-amber-950/20 via-slate-900/60 to-slate-900/60 shadow-xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <ShieldAlert className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                ACTIVE AI PREDICTION
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                Medium Risk (Confidence 88%)
              </span>
            </div>
            <h3 className="text-base font-bold text-white mt-0.5">
              &ldquo;Order ORD-1003 has a medium delay risk.&rdquo;
            </h3>
          </div>
        </div>

        {onApplyMitigation && (
          <button
            onClick={onApplyMitigation}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 transition-all flex items-center gap-1.5 shadow-md shadow-amber-600/30 self-start sm:self-auto"
          >
            <span>Move to Route 2</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Risk Reasons */}
        <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/60 space-y-2">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
            Identified Contributing Factors:
          </span>
          <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
            <li><strong>Long route:</strong> 18.1 km circuit leg across eastern perimeter</li>
            <li><strong>High delivery load:</strong> Truck 01 is carrying 84% rated weight capacity</li>
            <li><strong>Limited delivery window:</strong> Receiving dock cutoff leaves &lt;25m slack</li>
          </ul>
        </div>

        {/* AI Recommendation */}
        <div className="p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-500/30 space-y-2">
          <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider block">
            AI Operational Recommendation:
          </span>
          <p className="text-xs text-indigo-100 leading-relaxed font-medium">
            &ldquo;Move Warehouse C to Route 2 or re-sequence stop priority before returning to Central Depot to maintain 94.2% SLA.&rdquo;
          </p>
        </div>
      </div>
    </div>
  );
};
