import React from 'react';
import { Order } from '../../types';
import { Clock, MapPin, Truck, AlertTriangle, ShieldCheck } from 'lucide-react';

interface DeliveryTableProps {
  orders: Order[];
  onSelectOrder?: (order: Order) => void;
}

export const DeliveryTable: React.FC<DeliveryTableProps> = ({ orders, onSelectOrder }) => {
  return (
    <div className="glass-card rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
      <div className="p-5 border-b border-slate-800 flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-white">Live Dispatches & Risk Predictions</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time travel time assessment based on: Distance, Vehicle Speed & Service Time
          </p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/80 text-slate-400 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-800">
            <tr>
              <th className="px-5 py-3.5">Order ID</th>
              <th className="px-4 py-3.5">Destination</th>
              <th className="px-4 py-3.5">Distance</th>
              <th className="px-4 py-3.5">Vehicle</th>
              <th className="px-4 py-3.5">ETA</th>
              <th className="px-4 py-3.5">Risk Level</th>
              <th className="px-5 py-3.5">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80 text-slate-300">
            {orders.slice(0, 15).map((order) => {
              const isHigh = order.risk === 'High' || order.status === 'Delayed';
              const isMed = order.risk === 'Medium';

              return (
                <tr
                  key={order.id}
                  onClick={() => onSelectOrder && onSelectOrder(order)}
                  className={`hover:bg-slate-800/40 transition-colors cursor-pointer ${
                    order.orderNumber === 'ORD-1003' ? 'bg-amber-950/15' : ''
                  }`}
                >
                  <td className="px-5 py-4 font-mono font-bold text-white">
                    <div className="flex items-center gap-2">
                      <span>{order.orderNumber}</span>
                      {order.orderNumber === 'ORD-1003' && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          Focus
                        </span>
                      )}
                    </div>
                  </td>

                  <td className="px-4 py-4 font-semibold text-white">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{order.destination}</span>
                    </div>
                  </td>

                  <td className="px-4 py-4 font-mono text-slate-300">
                    {order.distanceKm.toFixed(1)} km
                  </td>

                  <td className="px-4 py-4">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <Truck className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{order.vehicle}</span>
                    </div>
                  </td>

                  <td className="px-4 py-4 font-mono font-semibold text-white">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{order.eta}</span>
                    </div>
                  </td>

                  <td className="px-4 py-4">
                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        isHigh
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : isMed
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {order.risk}
                    </span>
                  </td>

                  <td className="px-5 py-4 font-semibold">
                    <span
                      className={`text-xs ${
                        order.status === 'Delayed'
                          ? 'text-rose-400'
                          : order.status === 'In Transit'
                          ? 'text-sky-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {order.status === 'In Transit' ? 'On Route' : order.status}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
