import { ProductType, ProductForecast, DemandDataPoint } from '../types';

// Helper to generate a realistic date string (Day -30 to Day +30)
const getDateStr = (offsetDays: number): string => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

// Base daily volumes and seasonal multipliers for products
const BASE_DEMAND_PROFILES: Record<ProductType, {
  currentAvg: number;
  predictedAvg: number;
  growthPct: number;
  confidencePct: number;
  volatility: number;
  trend: number; // daily slope
  seasonality: number[]; // 7-day pattern [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
  explanation: string;
  trendReason: string;
  seasonalPattern: string;
}> = {
  Cement: {
    currentAvg: 92,
    predictedAvg: 108,
    growthPct: 17.4,
    confidencePct: 91,
    volatility: 8,
    trend: 0.55,
    seasonality: [1.05, 1.10, 1.08, 1.12, 1.15, 0.90, 0.60],
    explanation: 'Recent infrastructure project order volume is increasing and historical weekly patterns indicate higher construction demand during this dry-weather window.',
    trendReason: '3 new commercial development contracts in NCR region starting this sprint; concrete pour schedules concentrated in midweek.',
    seasonalPattern: 'Peak demand on Wednesdays & Fridays; lower dispatch on Sundays.',
  },
  Steel: {
    currentAvg: 42,
    predictedAvg: 49.5,
    growthPct: 18.0,
    confidencePct: 91,
    volatility: 4,
    trend: 0.35,
    seasonality: [1.10, 1.15, 1.12, 1.08, 1.05, 0.85, 0.65],
    explanation: 'Steel demand is predicted to increase by 18% over the next 7 days due to major foundation slab castings scheduled across Warehouse B and C zones.',
    trendReason: 'Raw rebar price rise anticipated next month, triggering front-loaded purchase orders from top contractors.',
    seasonalPattern: 'Heavy deliveries early in the week to supply mid-week fabrication shifts.',
  },
  Bricks: {
    currentAvg: 55,
    predictedAvg: 62.5,
    growthPct: 13.6,
    confidencePct: 88,
    volatility: 6,
    trend: 0.28,
    seasonality: [1.02, 1.05, 1.08, 1.10, 1.05, 0.92, 0.78],
    explanation: 'Masonry phase transitions across residential sectors 42 and 63 are creating sustained brick intake.',
    trendReason: 'Brick kiln production limits due to monsoon transition causing early buffer stock building.',
    seasonalPattern: 'Consistent dispatch Tuesday through Friday with site deliveries.',
  },
  Pipes: {
    currentAvg: 20,
    predictedAvg: 21.8,
    growthPct: 9.0,
    confidencePct: 94,
    volatility: 2.5,
    trend: 0.08,
    seasonality: [0.95, 1.02, 1.04, 1.05, 1.02, 0.96, 0.96],
    explanation: 'Stable baseline plumbing maintenance with moderate growth driven by municipal drainage retrofits.',
    trendReason: 'Quarterly municipal pipeline maintenance tender execution starting next week.',
    seasonalPattern: 'Steady demand with low variance across all operating weekdays.',
  },
  Tiles: {
    currentAvg: 18,
    predictedAvg: 20.7,
    growthPct: 15.0,
    confidencePct: 86,
    volatility: 3,
    trend: 0.12,
    seasonality: [0.90, 1.00, 1.05, 1.12, 1.18, 1.05, 0.70],
    explanation: 'Finishing works approaching on two multi-tower residential complexes, accelerating vitrified tile consumption.',
    trendReason: 'Interior fit-out contractors requesting staged bulk deliveries before month-end milestone billing.',
    seasonalPattern: 'Elevated demand towards Friday and Saturday as interior teams stage tiles for weekend installation.',
  },
};

// Deterministic pseudo-random helper for consistent demo data
function seededNoise(seed: number): number {
  const x = Math.sin(seed * 997 + 13.37) * 10000;
  return (x - Math.floor(x)) * 2 - 1; // range -1 to +1
}

// Generates historical (past 30 days) and forecast data points
export function generateDemandSeries(
  product: ProductType,
  forecastPeriodDays: 7 | 14 | 30 = 7,
  customGrowthModifier: number = 0
): DemandDataPoint[] {
  const profile = BASE_DEMAND_PROFILES[product];
  const points: DemandDataPoint[] = [];

  // Past 30 days: Day -29 to Day 0
  for (let i = -29; i <= 0; i++) {
    const dayOfWeek = (i + 35) % 7;
    const season = profile.seasonality[dayOfWeek];
    const trendContribution = (i + 30) * profile.trend * 0.4;
    const noise = seededNoise(i * 17 + product.charCodeAt(0)) * profile.volatility;
    const actual = Math.max(5, Math.round(profile.currentAvg * 0.88 * season + trendContribution + noise));

    points.push({
      date: getDateStr(i),
      dayIndex: i,
      actualDemand: actual,
      isForecast: false,
    });
  }

  // Connect the last actual point to the forecast series for continuity
  const lastActual = points[points.length - 1].actualDemand || profile.currentAvg;
  points[points.length - 1].predictedDemand = lastActual;
  points[points.length - 1].confidenceUpper = lastActual;
  points[points.length - 1].confidenceLower = lastActual;

  // Future days: Day 1 to Day forecastPeriodDays
  const targetAvg = profile.predictedAvg * (1 + customGrowthModifier);
  for (let i = 1; i <= forecastPeriodDays; i++) {
    const dayOfWeek = (i + 35) % 7;
    const season = profile.seasonality[dayOfWeek];
    const progress = i / forecastPeriodDays;
    const interpolatedMean = lastActual + (targetAvg - lastActual) * Math.min(1, progress * 1.2);
    const noise = seededNoise(i * 31 + product.charCodeAt(0)) * (profile.volatility * 0.45);
    const predicted = Math.max(5, Math.round(interpolatedMean * season + noise));

    // Confidence interval expands as forecast horizon extends
    const errorMargin = Math.round(predicted * (0.05 + 0.003 * i));

    points.push({
      date: getDateStr(i),
      dayIndex: i,
      predictedDemand: predicted,
      confidenceUpper: predicted + errorMargin,
      confidenceLower: Math.max(0, predicted - errorMargin),
      isForecast: true,
    });
  }

  return points;
}

export function getProductForecast(
  product: ProductType,
  periodDays: 7 | 14 | 30 = 7,
  customGrowthModifier: number = 0
): ProductForecast {
  const profile = BASE_DEMAND_PROFILES[product];
  const dataPoints = generateDemandSeries(product, periodDays, customGrowthModifier);

  const forecastPoints = dataPoints.filter((p) => p.isForecast && p.predictedDemand !== undefined);
  const avgForecast = forecastPoints.length > 0
    ? Math.round(forecastPoints.reduce((acc, p) => acc + (p.predictedDemand || 0), 0) / forecastPoints.length * 10) / 10
    : profile.predictedAvg;

  const effectiveGrowth = Math.round(((avgForecast - profile.currentAvg) / profile.currentAvg) * 1000) / 10;

  return {
    product,
    currentAvgDemand: profile.currentAvg,
    predictedAvgDemand: avgForecast,
    growthPct: effectiveGrowth,
    confidencePct: periodDays === 7 ? profile.confidencePct : periodDays === 14 ? profile.confidencePct - 4 : profile.confidencePct - 9,
    periodDays,
    explanation: profile.explanation,
    trendReason: profile.trendReason,
    seasonalPattern: profile.seasonalPattern,
    dataPoints,
  };
}
