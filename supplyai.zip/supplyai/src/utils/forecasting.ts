import { DemandDataPoint } from '../types';

/**
 * AI Predictive Analytics Demo Engine
 * 
 * Transparent forecasting algorithm combining:
 * 1. Simple / Exponential Moving Average (SMA / EMA)
 * 2. Linear Regression Trend (Slope & Intercept)
 * 3. Day-of-Week Seasonality Decomposition
 * 
 * Note: Clearly identified as an explainable heuristic demo model,
 * designed for easy replacement with an external Python/PyTorch/TensorFlow service or ARIMA/Prophet pipeline.
 */

export interface ForecastModelComponents {
  baselineMovingAverage: number;
  dailyTrendSlope: number;
  seasonalFactors: number[]; // 7 days (index 0 = Sun, 1 = Mon...)
  meanAbsoluteError: number;
}

/**
 * Calculates Simple Moving Average over the trailing N days
 */
export function calculateSimpleMovingAverage(values: number[], windowSize: number = 7): number {
  if (values.length === 0) return 0;
  const slice = values.slice(-windowSize);
  const sum = slice.reduce((acc, val) => acc + val, 0);
  return Math.round((sum / slice.length) * 10) / 10;
}

/**
 * Calculates Linear Regression Slope: Y = m*X + c
 */
export function calculateLinearTrendSlope(values: number[]): { slope: number; intercept: number } {
  const n = values.length;
  if (n <= 1) return { slope: 0, intercept: values[0] || 0 };

  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumXX = 0;

  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += values[i];
    sumXY += i * values[i];
    sumXX += i * i;
  }

  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  return {
    slope: Math.round(slope * 100) / 100,
    intercept: Math.round(intercept * 10) / 10,
  };
}

/**
 * Computes Day-of-Week Seasonality indices
 */
export function calculateSeasonalityIndices(points: DemandDataPoint[]): number[] {
  // 7 slots for days of week
  const daySums = [0, 0, 0, 0, 0, 0, 0];
  const dayCounts = [0, 0, 0, 0, 0, 0, 0];

  points.forEach((p, idx) => {
    if (p.actualDemand !== undefined) {
      const dayOfWeek = (idx + 4) % 7;
      daySums[dayOfWeek] += p.actualDemand;
      dayCounts[dayOfWeek]++;
    }
  });

  const overallAvg = points.reduce((acc, p) => acc + (p.actualDemand || 0), 0) / (points.length || 1);

  return daySums.map((sum, i) => {
    if (dayCounts[i] === 0 || overallAvg === 0) return 1.0;
    const avgForDay = sum / dayCounts[i];
    return Math.round((avgForDay / overallAvg) * 100) / 100;
  });
}
