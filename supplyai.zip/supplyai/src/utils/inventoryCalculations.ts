import { InventoryItem, InventoryStatus } from '../types';

/**
 * Supply Chain Inventory Calculations
 * 
 * Formulas used:
 * 1. Days Remaining = Current Stock / Daily Demand
 * 2. Expected Demand During Lead Time = Daily Demand * Lead Time (Days)
 * 3. Reorder Point (ROP) = Expected Demand During Lead Time + Safety Stock
 * 4. Recommended Order Quantity (ROQ) = (Reorder Point + Safety Stock) - Current Stock
 */

export interface InventoryCalculationResult {
  daysRemaining: number;
  reorderPoint: number;
  status: InventoryStatus;
  recommendedOrder: number;
  expectedDemandLeadTime: number;
}

export function calculateInventoryMetrics(
  currentStock: number,
  dailyDemand: number,
  leadTimeDays: number,
  safetyStock: number,
  minBatchSize: number = 25
): InventoryCalculationResult {
  if (dailyDemand <= 0) {
    return {
      daysRemaining: 999,
      reorderPoint: safetyStock,
      status: 'Healthy',
      recommendedOrder: 0,
      expectedDemandLeadTime: 0,
    };
  }

  // 1. Days Remaining
  const daysRemaining = Math.max(0, Math.floor(currentStock / dailyDemand));

  // 2. Expected Demand during Lead Time
  const expectedDemandLeadTime = Math.round(dailyDemand * leadTimeDays);

  // 3. Reorder Point: When stock drops to or below this level, reordering is triggered
  const reorderPoint = expectedDemandLeadTime + safetyStock;

  // 4. Determine Inventory Health Status
  let status: InventoryStatus = 'Healthy';
  if (currentStock <= reorderPoint * 0.75 || daysRemaining <= 2) {
    status = 'Critical';
  } else if (currentStock <= reorderPoint || daysRemaining <= 5) {
    status = 'Warning';
  }

  // 5. Recommended Order Quantity
  let recommendedOrder = 0;
  if (status !== 'Healthy') {
    const rawDeficit = (reorderPoint + safetyStock) - currentStock;
    // Round up to nearest batch size
    const batches = Math.ceil(Math.max(rawDeficit, minBatchSize) / minBatchSize);
    recommendedOrder = batches * minBatchSize;
  }

  return {
    daysRemaining,
    reorderPoint,
    status,
    recommendedOrder,
    expectedDemandLeadTime,
  };
}

/**
 * Re-evaluates an inventory item and produces an explainable AI diagnosis
 */
export function diagnoseInventoryItem(item: InventoryItem): {
  headline: string;
  recommendedAction: string;
  reason: string;
  riskLevel: 'Low' | 'Medium' | 'High';
} {
  if (item.status === 'Critical') {
    return {
      headline: `${item.product.toUpperCase()} INVENTORY ALERT`,
      recommendedAction: `Order ${item.recommendedOrder} units immediately.`,
      reason: `Forecasted demand (${item.dailyDemand}/day) will deplete available stock (${item.currentStock}) in ${item.daysRemaining} days. Current stock is below safety threshold (${item.safetyStock} units) during the ${item.leadTimeDays}-day replenishment window.`,
      riskLevel: 'High',
    };
  }

  if (item.status === 'Warning') {
    return {
      headline: `${item.product.toUpperCase()} REORDER WARNING`,
      recommendedAction: `Order ${item.recommendedOrder} units within 48 hours.`,
      reason: `Stock is currently at ${item.currentStock} units, which is near the reorder point of ${item.reorderPoint} units. Buffer remaining is ${item.daysRemaining} operating days.`,
      riskLevel: 'Medium',
    };
  }

  return {
    headline: `${item.product.toUpperCase()} STOCK HEALTHY`,
    recommendedAction: 'No immediate purchase order required.',
    reason: `Current stock of ${item.currentStock} units comfortably exceeds the reorder point of ${item.reorderPoint} units, providing ${item.daysRemaining} days of operating runway.`,
    riskLevel: 'Low',
  };
}
