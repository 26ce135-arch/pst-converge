/**
 * SupplyAI Formatting Utilities
 */

export function formatCurrency(amount: number, symbol: string = '₹'): string {
  const formatted = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 0,
  }).format(Math.round(amount));
  return `${symbol}${formatted}`;
}

export function formatDistance(km: number): string {
  return `${km.toFixed(1)} km`;
}

export function formatDurationMinutes(minutes: number): string {
  const hrs = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  if (hrs === 0) return `${mins}m`;
  return `${hrs}h ${mins}m`;
}

export function formatPercent(val: number, includeSign: boolean = false): string {
  const formatted = `${val.toFixed(1)}%`;
  if (includeSign && val > 0) return `+${formatted}`;
  return formatted;
}

export function formatNumber(val: number): string {
  return new Intl.NumberFormat('en-IN').format(val);
}
